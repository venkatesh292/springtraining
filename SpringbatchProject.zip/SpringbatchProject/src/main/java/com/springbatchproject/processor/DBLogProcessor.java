package com.springbatchproject.processor;

import org.springframework.batch.item.ItemProcessor;

import com.springbatchproject.model.Employee;


public class DBLogProcessor implements ItemProcessor<Employee,Employee> {

	@Override
	public Employee process(Employee item) throws Exception {
		
		System.out.println("Inserting employee : " + item);
        return item;
	}

}
