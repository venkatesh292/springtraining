package com.springbatchproject.SpringbatchProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbatchProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
