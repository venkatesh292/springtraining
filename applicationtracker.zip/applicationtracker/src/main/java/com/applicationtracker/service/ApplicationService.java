package com.applicationtracker.service;

import java.util.List;
import java.util.concurrent.CompletableFuture;



import com.applicationtracker.model.ApplicationDto;

public interface ApplicationService {

	
	CompletableFuture<List<ApplicationDto>> findAllApplications()throws Exception;
	
	CompletableFuture<ApplicationDto> findApplicationById(Long id) throws Exception;
	
	CompletableFuture<ApplicationDto> saveApplication(ApplicationDto application)throws Exception ;
	
	ApplicationDto updateApplication(ApplicationDto application)throws Exception;
	
	void deleteApplicationTicket(Long id)throws Exception;
}
