package com.applicationtracker.service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import com.applicationtracker.model.ApplicationDto;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ApplicationServiceImpl implements ApplicationService {

	private static final Logger logger = LogManager.getLogger(ApplicationServiceImpl.class.getName());

	@Value("${bugtracker.application.url}")
	private String bugTrackerUrl;

	@Value("${bugtracker.ticket.url}")
	private String bugTrackerTicket;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	@Async("asyncExecutor")
	@Retryable(value = { Exception.class }, maxAttemptsExpression = "${retry.maxAttempts}" , backoff = @Backoff(delayExpression = "${retry.delayExpression}"))
	public CompletableFuture<List<ApplicationDto>> findAllApplications() throws Exception {

		/*
		 * WebClient webClient = WebClient.create(bugTrackerUrl);
		 * 
		 * Flux<ApplicationDto> result =
		 * webClient.get().retrieve().bodyToFlux(ApplicationDto.class);
		 * 
		 * return result.collectList().block();
		 */
		
		/* Rest template */
		
		URI uri = new URI(bugTrackerUrl);
		
		ApplicationDto[] applications = restTemplate.getForObject(uri, ApplicationDto[].class);
		
		return CompletableFuture.completedFuture(Arrays.asList(applications)); 
		 	 
	}

	@Async("asyncExecutor")
	public CompletableFuture<ApplicationDto> findApplicationById(Long id) throws Exception {

		
		/*
		 * WebClient webClient = WebClient.create(bugTrackerUrl + "//" + id);
		 * 
		 * Mono<ApplicationDto> reponse =
		 * webClient.get().retrieve().bodyToMono(ApplicationDto.class);
		 * 
		 * return reponse.block();
		 */
		
		
		/*--REst Template----*/
		
		URI uri = new URI(bugTrackerUrl+"//"+id);
		
		ApplicationDto application = restTemplate.getForObject(uri,ApplicationDto.class);
		
		return CompletableFuture.completedFuture(application);
		
	}

	@Async("asyncExecutor")
	public CompletableFuture<ApplicationDto> saveApplication(ApplicationDto application) throws Exception {
/*
		WebClient webClient = WebClient.create(bugTrackerUrl);

		Mono<ApplicationDto> response = webClient.post().body(Mono.just(application), ApplicationDto.class).retrieve()
				.bodyToMono(ApplicationDto.class);

		return response.block();
		*/
		
		/*Rest Template--------*/	
		
	URI uri = new URI(bugTrackerUrl);
	
	HttpHeaders httpHeader = new HttpHeaders();
	
	HttpEntity<ApplicationDto> entity = new HttpEntity<ApplicationDto>(application,httpHeader);
	
	ApplicationDto result = restTemplate.postForObject(uri, entity,ApplicationDto.class);
	
	return CompletableFuture.completedFuture(result);
		
		
	}

	@Override
	public ApplicationDto updateApplication(ApplicationDto application) throws Exception {

		/*
		 * WebClient webClient = WebClient.create(bugTrackerUrl);
		 * 
		 * Mono<ApplicationDto> response = webClient.put().body(Mono.just(application),
		 * ApplicationDto.class).retrieve() .bodyToMono(ApplicationDto.class);
		 * 
		 * return response.block();
		 */
		
		/* Rest Template */
		
		URI uri = new URI(bugTrackerUrl);
		HttpHeaders httpHeaders = new HttpHeaders();
		HttpEntity<ApplicationDto> entity = new HttpEntity<ApplicationDto>(application,httpHeaders);
		
		restTemplate.put(uri,entity);
		
		return application;
	}

	@Override
	public void deleteApplicationTicket(Long id) throws Exception {

		/*
		 * WebClient webClient = WebClient.create("bugTrackerTicket" + "//" + id);
		 * 
		 * Mono<Void> bodyToMono = webClient.delete().retrieve().bodyToMono(void.class);
		 * bodyToMono.block();
		 */
		
		/* Rest Template */
		
		URI uri = new URI(bugTrackerTicket+"//"+id);
		restTemplate.delete(uri);
		
	}

	@Recover
	public List<Object> recover(Exception t) {
		logger.info("########### Recovery ##########");
		return Arrays.asList("Service recovered from failure.");
	}

}
