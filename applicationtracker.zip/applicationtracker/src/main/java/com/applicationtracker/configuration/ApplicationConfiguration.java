package com.applicationtracker.configuration;

import java.util.concurrent.Executor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

import com.google.common.base.Predicate;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@EnableAsync
public class ApplicationConfiguration {

	
	@Bean
    public Docket api(){
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(paths())
                .build()
                .apiInfo(apiInfo());
    }

    public Predicate<String> paths(){
        return input -> !input.contains("/error");
    }

    public ApiInfo apiInfo(){
        return new ApiInfoBuilder()
                .title("Application Tracker")
                .description("Tracking Application  Details")
                .version("1.0")
                .build();
    }
    
    @Bean
    public RestTemplate getRestTemplate() {
    	
    	return new RestTemplate();
    }
    
    @Bean(name = "asyncExecutor")
    public Executor asyncExecutor() {
    	
    	ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    	
    	executor.setCorePoolSize(3);
    	executor.setMaxPoolSize(3);
    	executor.setQueueCapacity(100);
    	executor.setThreadNamePrefix("AsyncThread-");
    	executor.initialize();
    	
    	return executor;
    }
}
