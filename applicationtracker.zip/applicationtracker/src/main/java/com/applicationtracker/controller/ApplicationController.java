package com.applicationtracker.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.applicationtracker.exception.RestRequestException;
import com.applicationtracker.model.ApplicationDto;
import com.applicationtracker.service.ApplicationService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/api/v1/applications")
public class ApplicationController {

	private static final Logger logger = LogManager.getLogger(ApplicationController.class.getName());

	@Autowired
	private ApplicationService applicationService;

	@GetMapping
	@ApiOperation(value = "Get Applications", notes = "Get all application details", response = List.class)
	public ResponseEntity<CompletableFuture<List<ApplicationDto>>> getAllApplications() throws RestRequestException, Exception {

		logger.info("Inside applicationController.findAllApplications");
		CompletableFuture<List<ApplicationDto>> applications = null;

		if (null != (applications = applicationService.findAllApplications())) {

			logger.info("Inside applicationController.findAllApplications applications: {} ", applications);

			return new ResponseEntity<CompletableFuture<List<ApplicationDto>>>(applications, HttpStatus.OK);
		} else {
			logger.info("Inside applicationController.findAllApplications applications: no data found");

			throw new RestRequestException("2001", "No application data found", HttpStatus.NO_CONTENT);
		}
	}
	
	@GetMapping("/async")
	@ApiOperation(value = "Asynchronous Call", notes ="Execute multiple getApplication call asynchronously",response = HttpStatus.class)
	public ResponseEntity<Object> getAllApplicationAsync() throws Exception {
	
		logger.info("Inside applicationController.getAllApplicationAsync");
		
		CompletableFuture<List<ApplicationDto>> applications1 = applicationService.findAllApplications();
		
		CompletableFuture<List<ApplicationDto>> applications2 = applicationService.findAllApplications();
		
		CompletableFuture<List<ApplicationDto>> applications3 = applicationService.findAllApplications();
		
		CompletableFuture.allOf(applications1,applications2,applications3).join();
		
		logger.info("applicationController.getAllApplicationAsync :  finshed execution");
		
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	

	@GetMapping("/{id}")
	@ApiOperation(value = "Find Application", notes = "Find application for the given application id", response = ApplicationDto.class)
	public ResponseEntity<CompletableFuture<ApplicationDto>> findApplication(
			@ApiParam(value = "Id value of the application need to retrieve ", required = true) @PathVariable("id") Long applId) throws RestRequestException,Exception {
		
		logger.info("Inside applicationController.findApplication");
		
		CompletableFuture<ApplicationDto> application = applicationService.findApplicationById(applId);
		
		CompletableFuture.allOf(application).join();

		if(null != application) {
		
			logger.info("Inside applicationController.findApplication application: {} ", application);
			
			return new ResponseEntity<CompletableFuture<ApplicationDto>>(application,HttpStatus.OK);
		}else {
		
			logger.info("Inside applicationController.findApplicationById application: no data found");
			
			throw new RestRequestException("2002", "Application not found", HttpStatus.NOT_FOUND);
			
		}

	}
	
	@PostMapping
	@ApiOperation(value = "Add Application", notes = "Add new application details", response = ApplicationDto.class)
	public ResponseEntity<CompletableFuture<ApplicationDto>> addApplication(
			@ApiParam(value = "Required to provide application deatils ", required = true) @RequestBody ApplicationDto application) throws RestRequestException,Exception {
		
		logger.info("Inside applicationController.addApplication");
		
		CompletableFuture<ApplicationDto> applicationObj = null;
		
		if (null != application && null != (applicationObj = applicationService.saveApplication(application))) {
		
			logger.info("applicationController.addApplication  after adding the  application: {}", applicationObj);
			
			return new ResponseEntity<CompletableFuture<ApplicationDto>>(applicationObj,HttpStatus.OK);
		}else {
		
			logger.info("Inside applicationController.addApplication while adding application: {}");
			
			throw new RestRequestException("30008","Not able to add the application",HttpStatus.BAD_REQUEST);	
		}

	}
	
	@PutMapping
	@ApiOperation(value = "Update Application", notes = " Update the existing application for the provided id ", response = ApplicationDto.class)
	public ResponseEntity<ApplicationDto> updateApplication(
			@ApiParam(value = "application details need to update", required = true) @RequestBody ApplicationDto application) throws RestRequestException,Exception {
		
			logger.info("applicationController.updateApplication requested application object to update : {}", application);

			if (null != application && null != application.getId()) {
				
				ApplicationDto applicationSave = applicationService.updateApplication(application);
				
				if (null != applicationSave) {
					logger.info("applicationController.updateApplication updated application entity : {}", applicationSave);
					return new ResponseEntity<ApplicationDto>(applicationSave, HttpStatus.OK);
				} else {
					logger.info("applicationController.updateApplication updated entity : {}");
					throw new RestRequestException("30008","Not able to update the application",HttpStatus.BAD_REQUEST);
				}
			} else {
				logger.info("applicationController.updateApplication inavlid update request");
				throw new RestRequestException("2002","Inavlid update request",HttpStatus.NOT_FOUND);
			}
		}
	
	@DeleteMapping("/{id}")
	@ApiOperation(value = "Delete ticket", notes = "Delete a application releted ticket", response = Object.class )
	public ResponseEntity<Object> deleteAppTicket(
			@ApiParam(value = "Id value of the ticket need to be delete", required = true) @PathVariable("id") Long ticketId)throws Exception{

		logger.info("Inside applicationController.deleteAppTicket, Id: {}", ticketId);

				applicationService.deleteApplicationTicket(ticketId);
				return new ResponseEntity<>(HttpStatus.OK);
			} 


}
