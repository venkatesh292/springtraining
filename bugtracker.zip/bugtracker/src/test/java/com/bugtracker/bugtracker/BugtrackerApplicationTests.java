package com.bugtracker.bugtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BugtrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
