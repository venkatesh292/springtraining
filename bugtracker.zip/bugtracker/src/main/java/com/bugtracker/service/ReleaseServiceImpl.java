package com.bugtracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bugtracker.entity.Release;
import com.bugtracker.repository.ReleaseRepository;

@Service
public class ReleaseServiceImpl implements ReleaseService {

	@Autowired
	private ReleaseRepository repository;
	
	@Override
	public List<Release> findAll() {
		
		return (List<Release>) repository.findAll() ;
	}

}
