package com.bugtracker.service;

import java.util.List;

import com.bugtracker.entity.Application;

public interface ApplicationService {

	List<Application> findByName(String name);
	
	List<Application> findByAppName(String name);
	
	List<Application> findAll();
}
