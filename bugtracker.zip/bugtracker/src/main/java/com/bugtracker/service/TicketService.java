package com.bugtracker.service;

import java.util.List;

import com.bugtracker.entity.Ticket;

public interface TicketService {
	
	List<Ticket> findAll();
}
