package com.bugtracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bugtracker.entity.Application;
import com.bugtracker.repository.ApplicationRepository;

@Service
public class ApplicationServiceImpl implements ApplicationService {

	@Autowired
	private ApplicationRepository repository;
	
	@Override
	public List<Application> findByName(String name) {
		
		return  repository.findByName("Expenses");
	}

	@Override
	public List<Application> findByAppName(String name) {
		
		return repository.findByAppName("Expenses");
	}

	@Override
	public List<Application> findAll() {
		
		return (List<Application>) repository.findAll();
	}

}
