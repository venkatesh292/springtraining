package com.bugtrackermvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BugtrackermvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(BugtrackermvcApplication.class, args);
	}

}
