package com.bugtrackermvc.repository;

import org.springframework.data.repository.CrudRepository;
import com.bugtrackermvc.entity.Ticket;


public interface TicketRepository extends CrudRepository<Ticket,Long> {

}
