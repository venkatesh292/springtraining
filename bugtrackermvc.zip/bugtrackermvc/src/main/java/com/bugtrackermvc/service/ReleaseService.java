package com.bugtrackermvc.service;

import java.util.List;

import com.bugtrackermvc.entity.Release;


public interface ReleaseService {

	List<Release> findAll();
	List<Release> searchByRelease(String keyword);
    Release findById(Long id);
    Release save(Release release);
}
