package com.bugtrackermvc.service;

import java.util.List;

import com.bugtrackermvc.entity.Application;


public interface ApplicationService {

	List<Application> findAll();
	
	List<Application> searchByName(String keyword);
	
	Application findById(Long id);
	
	Application save(Application application);
}
