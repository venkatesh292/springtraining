package com.bugtrackermvc.service;

import java.util.List;

import com.bugtrackermvc.entity.Ticket;

public interface TicketService {
	
	List<Ticket> findAll();
	Ticket findById(Long id);
	Ticket save(Ticket ticket);
	void delete(Long id);
}
