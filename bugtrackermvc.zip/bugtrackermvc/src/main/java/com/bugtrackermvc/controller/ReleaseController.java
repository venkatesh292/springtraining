package com.bugtrackermvc.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

import com.bugtrackermvc.entity.Application;
import com.bugtrackermvc.entity.Release;
import com.bugtrackermvc.exception.RestRequestException;
import com.bugtrackermvc.service.ReleaseService;


@Controller
public class ReleaseController {

	private static final Logger logger = LogManager.getLogger(ReleaseController.class.getName());
	@Autowired
	private ReleaseService releaseService;

	@GetMapping("/releases")
	public String findAllReleases(Model model) throws RestRequestException {

		logger.info("Inside ReleaseController.findAllReleases");
		
		List<Release> releases = releaseService.findAll();
		
			if (null != releases) {
				logger.info(" ReleaseController.findAllReleases Releases: {}", releases);
				model.addAttribute("releases", releases);
				
				return "releases";
			} else {
				logger.info(" ReleaseController.findAllReleases Releases: {}", releases);
				throw new RestRequestException(HttpStatus.NO_CONTENT,"30004","No content available");
		}
	}
	
	@GetMapping("/releasenew")
	public String releaseNew(Model model) {
		Release release = new Release();
		model.addAttribute("release", release);
		return "releasenew";
	}

	@PostMapping("/releasesave")
	public RedirectView submitForm(@ModelAttribute("release") Release release) throws RestRequestException {
		Release releaseObj = null;
		logger.info(" Inside ReleaseController.submitForm, release: {} ", release);

		if (null != release && null != (releaseObj = releaseService.save(release))) {

			logger.info("ReleaseController.submitForm  after adding the  release: {}", releaseObj);

			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			redirectView.setUrl("/releases");

			return redirectView;
		} else {
			logger.info("ReleaseController.submitForm while adding release: {}");
			throw new RestRequestException(HttpStatus.BAD_REQUEST, "30008", "Not able to save the release");
		}

	}
	
	@GetMapping("/release/edit/{id}")
	public String releaseEdit(Model model, @PathVariable("id") Long releaseId) throws RestRequestException {
		
		logger.info("Inside ReleaseController.releaseEdit id: {}", releaseId);
		
		Release release = releaseService.findById(releaseId);
		
		if(null != release) {
			model.addAttribute("release", release);
			
			logger.info("ReleaseController.releaseEdit, release: {}", release);
			
			return "releasedit";
		}else {
			logger.info(" ReleaseController.releaseEdit release: {}");
			throw new RestRequestException(HttpStatus.NOT_FOUND,"30006","release details not found");
		}
	}

	@GetMapping("/release/search")
	public String releaseSearch(Model model, @RequestParam String rsearch){
		
		logger.info("Inside ReleaseController.releaseSearch key: {} ", rsearch);
		
		List<Release> releases = releaseService.searchByRelease(rsearch);
		
		model.addAttribute("releases", releases);
		
		return "releases";

	}
}
