package com.bugtrackermvc.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.view.RedirectView;

import com.bugtrackermvc.entity.Application;
import com.bugtrackermvc.entity.Ticket;
import com.bugtrackermvc.exception.RestRequestException;
import com.bugtrackermvc.service.TicketService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;



@Controller
public class TicketController {

	@Autowired
	private TicketService ticketService;

	private static final Logger logger = LogManager.getLogger(TicketController.class.getName());

	@GetMapping("/tickets")
	public String getAllTickets(Model model) throws RestRequestException{

		

		logger.info("Inside TicketController.getAllTicket");
	
		  List<Ticket> tickets = ticketService.findAll();
		  
			if (null != tickets) {

				logger.info(" TicketController.getAllTicket tickets: {}", tickets);
				model.addAttribute("tickets", tickets);
				
				return "tickets";
			} else {
				logger.info(" TicketController.getAllTicket tickets: {}", tickets);
				throw new RestRequestException(HttpStatus.NO_CONTENT,"30004","No content available");
			}
	}
	
	@GetMapping("/ticketnew")
	public String ticketNew(Model model) {
		Ticket ticket = new Ticket();
		model.addAttribute("ticket", ticket);
		return "ticketnew";
	}

	@PostMapping("/ticketsave")
	public RedirectView submitForm(@ModelAttribute("ticket") Ticket ticket) throws RestRequestException {
		Ticket ticketObj = null;
		logger.info(" Inside TicketController.submitForm, ticket: {} ", ticket);

		if (null != ticket && null != (ticketObj = ticketService.save(ticket))) {

			logger.info("TicketController.submitForm  after adding the  ticket: {}", ticketObj);

			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			redirectView.setUrl("/tickets");

			return redirectView;
		} else {
			logger.info("TicketController.submitForm while adding ticket: {}");
			throw new RestRequestException(HttpStatus.BAD_REQUEST, "30008", "Not able to save the ticket");
		}

	}
	
	@GetMapping("/ticket/edit/{id}")
	public String ticketEdit(Model model, @PathVariable("id") Long ticketId) throws RestRequestException {
		
		logger.info("Inside TicketController.ticketEdit Id: {}", ticketId);
		
	    Ticket ticket = ticketService.findById(ticketId);
		
		if(null != ticket) {
			model.addAttribute("ticket", ticket);
			
			logger.info("TicketController.ticketEdit, ticket: {}", ticket);
			
			return "ticketedit";
		}else {
			logger.info(" TicketController.ticketEdit ticket: {}");
			throw new RestRequestException(HttpStatus.NOT_FOUND,"30006","Ticket details not found");
		}
	}
	
	@GetMapping("/ticket/delete/{id}")
	public RedirectView deleteTicket(
			@PathVariable("id") Long ticketId){

		logger.info("Inside TicketController.deleteTicket, Id: {}", ticketId);

				ticketService.delete(ticketId);
				
				RedirectView redirectView = new RedirectView();
				redirectView.setContextRelative(true);
				redirectView.setUrl("/tickets");

				return redirectView;
			} 

}
