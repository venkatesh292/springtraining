package com.bugtrackermvc.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

import com.bugtrackermvc.entity.Application;
import com.bugtrackermvc.exception.RestRequestException;
import com.bugtrackermvc.service.ApplicationService;


@Controller
public class ApplicationController {

	private static final Logger logger = LogManager.getLogger(ApplicationController.class.getName());

	@Autowired
	private ApplicationService applicationService;

	@GetMapping("/applications")
	public String getApplications(Model model) throws RestRequestException {

		logger.info("Inside ApplicationController.getApplications");

		List<Application> applications = applicationService.findAll();

		if (null != applications) {

			model.addAttribute("applications", applications);

			logger.info(" ApplicationController.getApplications Aapplications: {}", applications);

			return "applications";
		} else {
			logger.info(" ApplicationController.getApplications Aapplications: {}");
			throw new RestRequestException(HttpStatus.NO_CONTENT, "30004", "No content available");
		}

	}

	@GetMapping("/applicationnew")
	public String applicationNew(Model model) {
		Application application = new Application();
		model.addAttribute("application", application);
		return "applicationnew";
	}

	@PostMapping("/applicationsave")
	public RedirectView submitForm(@ModelAttribute("application") Application application) throws RestRequestException {
		Application applicationObj = null;
		logger.info(" Inside ApplicationController.submitForm, application: {} ", application);

		if (null != application && null != (applicationObj = applicationService.save(application))) {

			logger.info("ApplicationController.submitForm  after adding the  application: {}", applicationObj);

			RedirectView redirectView = new RedirectView();
			redirectView.setContextRelative(true);
			redirectView.setUrl("/applications");

			return redirectView;
		} else {
			logger.info("ApplicationController.submitForm while adding application: {}");
			throw new RestRequestException(HttpStatus.BAD_REQUEST, "30008", "Not able to save the application");
		}

	}
	
	@GetMapping("/application/edit/{id}")
	public String applicationEdit(Model model, @PathVariable("id") Long appId) throws RestRequestException {
		
		logger.info("Inside ApplicationController.applicationEdit Id: {} ", appId);
		
		Application application = applicationService.findById(appId);
		
		if(null != application) {
			model.addAttribute("application", application);
			
			logger.info("ApplicationController.applicationEdit, application: {}", application);
			
			return "applicationedit";
		}else {
			logger.info(" ApplicationController.applicationEdit Aapplications: {}");
			throw new RestRequestException(HttpStatus.NOT_FOUND,"30006","Application details not found");
		}
	}
	
	@GetMapping("/application/search")
	public String applicationSearch(Model model, @RequestParam String asearch){
		
		logger.info("Inside ApplicationController.applicationSearch key: {} ", asearch);
		
		List<Application> applications = applicationService.searchByName(asearch);
		
		model.addAttribute("applications", applications);
		
		return "applications";
		/*
		
		
		if(null != application) {
			model.addAttribute("application", application);
			
			logger.info("ApplicationController.applicationEdit, application: {}", application);
			
			return "applicationedit";
		}else {
			logger.info(" ApplicationController.applicationEdit Aapplications: {}");
			throw new RestRequestException(HttpStatus.NOT_FOUND,"30006","Application details not found");
		}*/
	}

}
