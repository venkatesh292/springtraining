package com.springproject.ioc.applicationcontext.filesystem;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		
		ApplicationContext fileSystemContext = new FileSystemXmlApplicationContext("//Users//venkatesh.nayak//sts_workspace//SpringProject//Resources//filesystemxmlapplicationcontext.xml");
		
		Student student = fileSystemContext.getBean("student", Student.class);
		
		student.getStudentDetails();

	}

}
