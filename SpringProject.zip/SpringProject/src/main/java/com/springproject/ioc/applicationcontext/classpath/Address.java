package com.springproject.ioc.applicationcontext.classpath;

public class Address {
    
	String city = "Karwar";
	String state = "Karnataka";
	
	public void getAddressDetails() {
		
		System.out.println("City : "+city+", state : "+ state);
	}
	
}
