package com.springproject.aop.example;

import javax.naming.directory.InvalidAttributesException;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.springproject.dao.jdbctemplate");

		context.refresh();

		EmplService emplService = context.getBean("emplServiceImpl", EmplServiceImpl.class);
		
		int count = 0;
		try {
		//	Employee employee= null;
			count = emplService.saveEmployee(new Employee(10,"Shivkumar chandra",10000));
	//		count = emplService.saveEmployee(employee);
		//	System.out.println("Total number of rows inserted : "+ count);
		} catch (InvalidAttributesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
