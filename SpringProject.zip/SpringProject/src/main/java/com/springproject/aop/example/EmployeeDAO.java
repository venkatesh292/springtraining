package com.springproject.aop.example;

import java.util.List;

public interface EmployeeDAO {

 int saveEmployee(Employee employee);
 
 int updateEmployee(int id,String name);
 
 int deleteEmployee(int id);
 
 List<Employee> getAllEmployee();
 
 Employee getEmployee(int id);
 
 int updateMultiEmployee(List<Employee> employee);
}
