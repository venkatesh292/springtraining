package com.springproject.aop.xml;

public class Employee {

	private int emmpId;
	private String empName;
	private String empSalary;
	public int getEmmpId() {
		return emmpId;
	}
	public void setEmmpId(int emmpId) {
		this.emmpId = emmpId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmployeeDetails() {
		
		return "Employee [emmpId=" + emmpId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
	
	
}
