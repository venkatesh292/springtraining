package com.springproject.aop.xml;

public class LoggingAspects {

	
	public void before() {
		
		System.out.println("------------Entering Method----------------");
	}
	
	public void after() {
		
		System.out.println("--------------Completed Method Execution----------------");
	}
}
