package com.springproject.bean.autowire.xml;

public class Student {

	private int studetId;
	private String studentName;
	private Marks marks;
	
	public int getStudetId() {
		return studetId;
	}
	public void setStudetId(int studetId) {
		this.studetId = studetId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public Marks getMarks() {
		return marks;
	}
	public void setMarks(Marks marks) {
		this.marks = marks;
	}
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Marks marks) {
		super();
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Student [studetId=" + studetId + ", studentName=" + studentName + ", marks=" + marks + "]";
	}
	
	
}
