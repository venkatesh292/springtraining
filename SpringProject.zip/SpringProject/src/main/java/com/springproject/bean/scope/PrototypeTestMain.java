package com.springproject.bean.scope;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PrototypeTestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("prototypescope.xml");
		
		Employee employee = context.getBean("employee", Employee.class);
		
		System.out.println(employee.hashCode());
		
        Employee employee2 = context.getBean("employee", Employee.class);
		
		System.out.println(employee2.hashCode());
		
	}

}
