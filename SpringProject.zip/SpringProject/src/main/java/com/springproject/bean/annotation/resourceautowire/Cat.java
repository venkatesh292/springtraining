package com.springproject.bean.annotation.resourceautowire;

import org.springframework.stereotype.Component;


@Component
public class Cat implements Animal {

	@Override
	public void animalDetails() {
		// TODO Auto-generated method stub

		System.out.println("This is a cat class");
	}

}
