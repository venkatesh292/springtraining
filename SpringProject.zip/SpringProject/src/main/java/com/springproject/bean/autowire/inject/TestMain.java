package com.springproject.bean.autowire.inject;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.springproject.bean.autowire.inject");
		
		context.refresh();
		
		User user = context.getBean("user",User.class);
		
		user.showDetails();
	}

}
