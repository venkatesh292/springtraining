package com.springproject.bean.annotation.resourceautowire;

public interface Animal {

 void animalDetails();
}
