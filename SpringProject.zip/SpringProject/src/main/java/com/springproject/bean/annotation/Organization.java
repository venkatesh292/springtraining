package com.springproject.bean.annotation;

import org.springframework.stereotype.Repository;

@Repository
public class Organization {

	private String orgName="Apple";
	private String ceo ="Team Cook";
	
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	@Override
	public String toString() {
		return "Organization [orgName=" + orgName + ", ceo=" + ceo + "]";
	}
	
	
}
