package com.springproject.bean.importsinglefile;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("organisationbean.xml");
		Organization organisation = context.getBean("organization",Organization.class);
		organisation.getOrganizationDetails();
		
		Employee employee = context.getBean("employee",Employee.class);
		
		System.out.println(employee);
		
		Department department = context.getBean("department", Department.class);
		
		System.out.println(department);
	}

}
