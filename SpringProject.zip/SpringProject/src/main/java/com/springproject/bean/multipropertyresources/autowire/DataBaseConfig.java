package com.springproject.bean.multipropertyresources.autowire;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DataBaseConfig {

	@Value("${db.host.url}")
	private String dbHost;
	
	@Value("${db.port.number}")
	private String port;
	
	@Value("${db.service.name}")
	private String dbName;
	
	@Value("${db.user}")
	private String dbUser;
	
	@Value("${db.password}")
	private String dbPassword;
	
	
	public String getDbHost() {
		return dbHost;
	}
	public void setDbHost(String dbHost) {
		this.dbHost = dbHost;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getDbUser() {
		return dbUser;
	}
	public void setDbUser(String dbUser) {
		this.dbUser = dbUser;
	}
	public String getDbPassword() {
		return dbPassword;
	}
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}
	
	public void getDBConfigDetails() {
		System.out.println("DB HOST: "+ this.getDbHost());
		System.out.println("DB PORT: "+ this.getPort());
		System.out.println("DB NAME: "+ this.getDbName());
		System.out.println("DB USER: "+ this.getDbUser());
		System.out.println("DB PASSWORD: "+ this.getDbPassword());
	}
	
	
}
