package com.springproject.bean.property;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("propertyfileconfig.xml");
		
		DataBaseConfig databaseConfig = context.getBean("databaseconfig", DataBaseConfig.class);
		
		databaseConfig.getDBConfigDetails();
		
		System.out.println("-------------Mail Configuration Details--------------------");
		
		MailConfig mailConfig = context.getBean("mailconfig", MailConfig.class);
		
		mailConfig.getMailConfigDetails();

	}

}
