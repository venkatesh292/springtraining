package com.springproject.bean.property;


public class MailConfig {

	private String smtpHost;
	private String port;
	private String userName;
	private String password;
	
	public String getSmtpHost() {
		return smtpHost;
	}
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void getMailConfigDetails() {
		
		System.out.println("SMTP HOST: "+ this.getSmtpHost());
		System.out.println("PORT: "+this.getPort());
		System.out.println("User Name: "+ this.getUserName());
		System.out.println("Password: "+ this.getPassword());
	}
	
}
