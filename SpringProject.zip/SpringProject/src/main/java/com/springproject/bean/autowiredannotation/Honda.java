package com.springproject.bean.autowiredannotation;

import org.springframework.stereotype.Component;

@Component
public class Honda implements Vehical {

	@Override
	public void showVehical() {
		// TODO Auto-generated method stub
		
		System.out.println("This is honda class");

	}

}
