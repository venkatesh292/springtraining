package com.springproject.bean.autowiredannotation;

public interface Vehical {

	void showVehical();
}
