package com.springproject.bean.annotation.resourceautowire;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.springproject.bean.annotation.autowire");
		
		context.refresh();
		
		AnimalConf animalConf = context.getBean("animalConf",AnimalConf.class);
		
		animalConf.showAnimalDetails();
	}

}
