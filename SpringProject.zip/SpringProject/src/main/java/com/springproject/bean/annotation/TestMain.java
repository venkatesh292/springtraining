package com.springproject.bean.annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		// context.scan("com.springproject.bean.annotation");

		context.register(Employee.class, Address.class, Organization.class);

		context.refresh();

		Employee employee = context.getBean("employee", Employee.class);

		System.out.println(employee);

		Address address = context.getBean("address", Address.class);

		System.out.println(address);

		Organization organization = context.getBean("organization", Organization.class);

		System.out.println(organization);
	}

}
