package com.springproject.bean.withoutimport;

import java.util.List;

import com.springproject.bean.importsinglefile.Department;
import com.springproject.bean.importsinglefile.Employee;

public class Organization {

	private List<Employee> employee;
	private List<Department> department;
	
	public List<Employee> getEmployee() {
		return employee;
	}
	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}
	public List<Department> getDepartment() {
		return department;
	}
	public void setDepartment(List<Department> department) {
		this.department = department;
	}
	
	public void getOrganizationDetails() {
		
		System.out.println("Employee Details: "+ this.getEmployee());
		
		System.out.println("Department Details: "+ this.getDepartment());
	}
}
