package com.springproject.dao.jdbctemplate.xml;

import java.util.List;


public interface EmployeeDAO {

	int saveEmployee(Employee employee);

	int updateEmployee(int id, String name);

	int deleteEmployee(int id);

	List<Employee> getAllEmployee();

	Employee getEmployee(int id);

	int updateMultiEmployee(List<Employee> employee);
}
