package com.springproject.dao.jdbctemplate;

import java.util.List;

import javax.naming.directory.InvalidAttributesException;

public interface EmplService {

	int saveEmployee(Employee employee)throws InvalidAttributesException;
	
	int updateEmployee(int id,String name);
	
	int deleteEmployee(int id);
	 
	List<Employee> getAllEmployee();
	
	Employee getEmployee(int id);
	
	int updateMultiEmployee(List<Employee> employee);
	 
}
