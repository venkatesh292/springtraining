package com.springproject.dao.jdbctemplate.xml;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;
    
	

	public int updateEmployee(int id, String name) {
		// TODO Auto-generated method stub
		return employeeDAO.updateEmployee(id, name);
	}

	public int deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeDAO.deleteEmployee(id);
	}

	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployee();
	}

	
	public Employee getEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployee(id);
	}

	public int updateMultiEmployee(List<Employee> employee) {
		// TODO Auto-generated method stub
		return employeeDAO.updateMultiEmployee(employee);
	}

	public int saveEmployee(Employee employee) {
		
		return employeeDAO.saveEmployee(employee);
	}

}
