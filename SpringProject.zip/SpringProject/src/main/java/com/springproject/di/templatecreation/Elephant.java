package com.springproject.di.templatecreation;

public class Elephant extends Animal {
	
	private String location;

	public void init() {
		System.out.println("Initializing the elepahnt bean");
	}
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	public void getElephantDetails() {
		
		System.out.println("Name: "+ this.getName());
		System.out.println("Age: "+ this.getAge());
		System.out.println("Location: "+ this.getLocation());
	}
	
	public void destroyElephant() {
		System.out.println("Destroying the elpahnt bean");
	}

}
