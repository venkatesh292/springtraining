package com.springproject.di.settor.collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("collectioninjection.xml");
		Organisation organisation = context.getBean("organisation",Organisation.class);
		
		organisation.getOrganizationDetails();
	}

}
