package com.springproject.di.settor.collections;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Organisation {
 
   private List<String> students;
   private Set<String> depart;
   private Map staf;
   private Properties propert;
   
public List<String> getStudents() {
	return students;
}
public void setStudents(List<String> students) {
	this.students = students;
}
public Set<String> getDepart() {
	return depart;
}
public void setDepart(Set<String> depart) {
	this.depart = depart;
}
public Map getStaf() {
	return staf;
}
public void setStaf(Map staf) {
	this.staf = staf;
}
public Properties getPropert() {
	return propert;
}
public void setPropert(Properties propert) {
	this.propert = propert;
}
  
public void getOrganizationDetails() {
	System.out.println("Students: "+ this.students);
	System.out.println("Departments: "+ this.depart);
	System.out.println("Staff: "+ this.staf);
	System.out.println("Properties:"+ this.propert);
}
   
   
}
