package com.springproject.di.setterbean;

public class Student {

	private int id ;
	private String name;
	private String address;
	private Marks marks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Marks getMarks() {
		return marks;
	}
	public void setMarks(Marks marks) {
		this.marks = marks;
	}
	
	public void getStudentDetails() {
		System.out.println(this.id);
		System.out.println(this.name);
		System.out.println(this.address);
	    marks.getmarkDetails();
	}
	
}
