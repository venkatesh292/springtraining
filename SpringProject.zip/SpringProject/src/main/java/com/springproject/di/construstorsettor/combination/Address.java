package com.springproject.di.construstorsettor.combination;

public class Address {

	private String street_name;
	private String city;
	private String State;
	
	public String getStreet_name() {
		return street_name;
	}
	public void setStreet_name(String street_name) {
		this.street_name = street_name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	
	public void getAddress() {
		System.out.println("----------------Address Detail-----------------");
		System.out.println("Street Name: "+this.street_name);
		System.out.println("City: "+this.city);
		System.out.println("State: "+this.State);
		System.out.println("--------------------------------------------------");
	}
}
