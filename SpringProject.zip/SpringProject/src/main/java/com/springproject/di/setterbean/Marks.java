package com.springproject.di.setterbean;

public class Marks {

	private String subject;
	private int mark;
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getMark() {
		return mark;
	}
	public void setMark(int mark) {
		this.mark = mark;
	}
	
	public void getmarkDetails() {
		System.out.println(this.subject);
		System.out.println(this.mark);
	}
	
}
