package com.springproject.di.constructor.collections;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class OrganisationForRef {

	private List<Student> students;
	private Set<Department> department;
	private Map<Staff,StaffAddress> staff;
	private Properties numberOfStudents;
	
	public OrganisationForRef(List<Student> students, Set<Department> department, Map<Staff, StaffAddress> staff,
			Properties numberOfStudents) {
		super();
		this.students = students;
		this.department = department;
		this.staff = staff;
		this.numberOfStudents = numberOfStudents;
	}
	
	public void getOrganisationDetails() {
		
		System.out.println("Student Details: "+ this.students);
		System.out.println("Department Details: "+this.department);
		System.out.println("Staff Details: "+ this.staff);
		System.out.println("Number of students: "+ this.numberOfStudents);
	}
	
}
