package com.springproject.di.construstorsettor.combination;

public class Employee {
	
	private int emp_id;
	private String emp_name;
	private String emp_depart;
	private int emp_salary;
	private Address address;
	
	public Employee(int emp_id, String emp_name, String emp_depart, int emp_salary, Address address) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_depart = emp_depart;
		this.emp_salary = emp_salary;
		this.address = address;
	}
	public void getEmployeeDetails() {
		System.out.println("----------------Employee Details----------------");
		System.out.println("Emaployee ID: "+this.emp_id);
		System.out.println("Employee Name: "+this.emp_name);
		System.out.println("Employee Department: "+this.emp_depart);
		System.out.println("Employee Salary: "+this.emp_salary);
		address.getAddress();
		
	}
	
}
