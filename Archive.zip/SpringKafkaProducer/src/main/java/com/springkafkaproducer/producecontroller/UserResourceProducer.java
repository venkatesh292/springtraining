package com.springkafkaproducer.producecontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springkafkaproducer.model.User;

@RestController
@RequestMapping("kafka")
public class UserResourceProducer {

	@Autowired
	KafkaTemplate<String, User> kafkaTemplate;

	private static final String TOPIC = "USER_RESOUR";

	@GetMapping("publish/{message}")
	public String postUser(@PathVariable("message") String msg) {

		kafkaTemplate.send(TOPIC, new User("Venkatesh","Ankola","10000"));

		return "Published Successfully";

	}
}
