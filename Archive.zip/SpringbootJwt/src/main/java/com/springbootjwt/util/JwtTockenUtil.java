package com.springbootjwt.util;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTockenUtil implements Serializable {

	private static final long serialVersionUID = -4862171122970453457L;

	public static final long JWT_TOKEN_VALIDITY = 5 * 60 * 60;

	@Value("${jwt.token.secret}")
	private String secretKey;

	public String generateToken(UserDetails userDetails) {

		Map<String, Object> claims = new HashMap<>();

		return doGenerateToken(claims, userDetails);
	}

	public String getUserNameFromClaims(String token) {

		return getClaime(token, Claims::getSubject);
	}

	public Date getExpireDateFromClaims(String token) {

		return getClaime(token, Claims::getExpiration);
	}

	public <T> T getClaime(String tocken, Function<Claims, T> resolver) {

		Claims claime = parseAllClaimes(tocken);
		return resolver.apply(claime);
	}

	public Claims parseAllClaimes(String token) {

		return Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token).getBody();
	}

	public Boolean isExpiredToken(String token) {

		final Date expireDate = getExpireDateFromClaims(token);
		
		System.out.println("Expiration Date : " + expireDate);
		return (expireDate.before(new Date()));
	}

	private String doGenerateToken(Map<String, Object> claims, UserDetails userDetails) {

		return Jwts.builder().setClaims(claims).setSubject(userDetails.getUsername())
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
				.signWith(SignatureAlgorithm.HS512, secretKey).compact();
	}

	public Boolean validateToken(UserDetails userDetails, String token) {

		final String userName = getUserNameFromClaims(token);

		System.out.println("user Name : "+userName );
		
		return (userName.equals(userDetails.getUsername()) && !isExpiredToken(token));
	}
}
