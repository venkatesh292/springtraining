package com.springbootjwt.util;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class JwtRequestTokenFilter extends OncePerRequestFilter {

	
	@Autowired
	private JwtTockenUtil jwtTockenUtil;
	
	@Autowired
	private UserDetailsService jwtUserDetailsService;
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String username = null;
		String jwtToken = null;

		final String requestHeader = request.getHeader("Authorization");

		if (null != requestHeader && requestHeader.startsWith("Bearer ")) {

			jwtToken =  requestHeader.substring(7);
			
			username = jwtTockenUtil.getUserNameFromClaims(jwtToken);
			
		} else {
			logger.warn("JWT Token does not begin with Bearer String");
		}

		if(null != username && SecurityContextHolder.getContext().getAuthentication() == null) {
			
			
			UserDetails userDetails = jwtUserDetailsService.loadUserByUsername(username);
			
			if(jwtTockenUtil.validateToken(userDetails, jwtToken)) {
				
				
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
				
				usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			}
			
			
		}
		filterChain.doFilter(request, response);
	}

}
