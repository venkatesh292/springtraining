package com.springbatchproject.springbatchlauncher;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SpringBatchLauncher {

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	@Qualifier("jobOne")
	private Job jobOne;

	@Autowired
	@Qualifier("jobTwo")
	private Job jobTwo;
	

	 @Scheduled(cron = "0 */1***?")
	public void perform() throws Exception {

		JobParameters params = new JobParametersBuilder().addString("JobID", String.valueOf(System.currentTimeMillis()))
				.toJobParameters();

		jobLauncher.run(jobOne, params);
	}

	@Scheduled(cron = "0 */5 * * * ?")
	public void peformJobTwo() throws Exception {

		JobParameters parameters = new JobParametersBuilder()
				.addString("JobID", String.valueOf(System.currentTimeMillis())).toJobParameters();

		jobLauncher.run(jobTwo, parameters);
	}

}
