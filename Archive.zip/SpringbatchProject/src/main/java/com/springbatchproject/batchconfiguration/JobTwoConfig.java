package com.springbatchproject.batchconfiguration;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.springbatchproject.tasks.MyTaskOne;
import com.springbatchproject.tasks.MyTaskTwo;

@Configuration
@EnableBatchProcessing
public class JobTwoConfig {

	@Autowired
	JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Step stepThree() {
		
		return stepBuilderFactory.get("stepThree").tasklet(new MyTaskOne()).build();
	}
	
	@Bean
	public Step stepFour() {
		
		return stepBuilderFactory.get("stepFour").tasklet(new MyTaskTwo()).build();
	}
	
	@Bean
	public Job jobTwo() {
		
		return jobBuilderFactory.get("jobTwo").incrementer(new RunIdIncrementer()).start(stepThree()).next(stepFour()).build();
	}
	
}
