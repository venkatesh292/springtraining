package com.applicationtracker.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class RestRequestExceptionHandler{

	@ExceptionHandler(value = RestRequestException.class)
	public ResponseEntity<Object> handleRestRequestException(final RestRequestException restException, WebRequest webRequest) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode(restException.getErrorCode());
		errorResponse.setErrorMessage(restException.getErrorMessage());

		return new ResponseEntity<Object>(errorResponse, new HttpHeaders(), restException.getHttpStatus());
	}
	
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<Object> handleGeneralException(final Exception exception, WebRequest webRequest) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode("1002");
		errorResponse.setErrorMessage(exception.toString());

		return new ResponseEntity<Object>(errorResponse, new HttpHeaders(),HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
