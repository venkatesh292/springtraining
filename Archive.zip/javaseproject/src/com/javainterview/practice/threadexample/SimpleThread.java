package com.javainterview.practice.threadexample;

public class SimpleThread extends Thread{
	
	private SyncMethodExample exam ;
	
	public SimpleThread(SyncMethodExample exam) {
		this.exam = exam;
	}
	public void run() {
		
		exam.perform();
		
	}

}
