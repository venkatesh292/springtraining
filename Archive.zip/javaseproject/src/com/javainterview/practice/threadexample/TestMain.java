package com.javainterview.practice.threadexample;

public class TestMain {

	public static void main(String[] args) {
		
		SyncMethodExample exam = new SyncMethodExample();
		
		SyncMethodExample exam2 = new SyncMethodExample();
		
		SimpleThread t1 = new SimpleThread(exam);
		
		SimpleThread t2 = new SimpleThread(exam2);
		
		t1.start();
		
		t2.start();

	}

}
