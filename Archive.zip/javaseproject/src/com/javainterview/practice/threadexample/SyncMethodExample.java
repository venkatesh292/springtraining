package com.javainterview.practice.threadexample;

public class SyncMethodExample {

	public static synchronized void perform() {
		
       for(int i=0;i<5;i++) {
			
			System.out.println(i+": "+ Thread.currentThread().getName());
		}
	}
}
