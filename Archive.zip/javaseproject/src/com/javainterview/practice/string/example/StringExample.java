package com.javainterview.practice.string.example;

import java.util.HashMap;
import java.util.Map;

public class StringExample {

	public static void stringCount() {

		String n = ("Venkatesh Nayak".replaceAll(" ", "")).toLowerCase();

		Map<String, Integer> strMap = new HashMap<String, Integer>();

		//char[] arr = n.toCharArray();

		for (int i = 0; i < n.length(); i++) {

		//	String key = Character.toString(arr[i]);
			
			 String key =Character.toString(n.charAt(i));

			if (strMap.containsKey(key)) {

				strMap.put(key, strMap.get(key) + 1);
			} else {

				strMap.put(key, 1);
			}
		}

		strMap.forEach((k, v) -> System.out.println(k + ":\t" + v));
		System.out.println("\n");
	}

	public static void stringReplaceSpace() {
		
		String str = "today we dont have any   class";
		System.out.println("Replaced String\n"+ str.replace(" ","")+"\n");
	}
	
	public static void concatCharArray() {
		
		char[] arr = {'v','e','n','k','a','t','e','s','h'};
		System.out.println("Coverting char[] array to string:\n"+ String.valueOf(arr)+"\n");
	}
	
	public static void joinString() {
		
		String[] strArray = {"ramesh","guru","naresh","suma"};
		
		System.out.println("Concatinated array of string:\n"+ String.join(" ", strArray)+"\n");
		
		System.out.println("Concatinated array of string:\n"+ String.join("-", strArray)+"\n");
				
	}
	public static void showCharacterPosission() {
		
		
		int possion =4;
		
		String name = "Venkatesh";
		
		
		char ch = name.charAt(possion-1);
		
		
		System.out.println("Character at possion\t"+possion+":\n"+ch);
	}
	
	public static void CountTheOccurenceOfChar() {
		
		String name= "Venkatesh".toLowerCase();
		int count = 0;
		for(int i =0 ;i<name.length();i++) {
			if(name.charAt(i)== 'e') count ++;
		}
		System.out.println("Number of occurence of character:\n"+ count);
	}
	
	public static void checkReference() {
		
		String s1="java string";  
		
		System.out.println(s1);  
		
		System.out.println("S1 hashcode: "+ s1.hashCode());
		
	    System.out.println("New HashCode: "+ s1.concat("is immutable").hashCode());  
		
	    System.out.println(s1);  
		System.out.println(s1.hashCode());  
		
		s1=s1.concat(" is immutable so assign it explicitly");  
		
		System.out.println(s1);  
		
		System.out.println(s1.hashCode());
	}
	
	public static void main(String[] args) {

		stringCount();
		
		stringReplaceSpace();
		
		concatCharArray();
		
		joinString();
		
		showCharacterPosission();
		
		CountTheOccurenceOfChar();
		
		checkReference();
	
	}

}
