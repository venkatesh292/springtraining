package com.javainterview.practice.exception.customize;

public class TestMain {

	public static void printAge() throws CustomeException {
	int age =18;
	
		if(age<=18) {
			
			throw new CustomeException("Not Valid");
		}else {
			System.out.println("Age is valid");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			printAge();
		} catch (CustomeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
