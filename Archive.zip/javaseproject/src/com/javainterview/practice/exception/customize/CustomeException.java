package com.javainterview.practice.exception.customize;

public class CustomeException extends Exception {

	CustomeException(String s){
		super(s);
	}
}
