package com.javainterview.practice.design.pattern.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SmallSubstarctArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> numList = Arrays.asList(new Integer[]{1,2,3,4,5,6,7,8});
		
		List<Integer> numCopy = new ArrayList<Integer>(numList);
		
		Map<String,Integer> subCombination = new HashMap<String, Integer>();
		
		for(int i =0; i<numList.size();i++) {
			
			for(int j=0;j<numCopy.size();j++) {
				
			int sub = numList.get(i)- numList.get(j);
			
			String key = numList.get(i).toString()+ numList.get(j).toString();
			
			subCombination.put(key,sub);
			}
		}
		
		List<Integer> sortedLs = new ArrayList<Integer>();
		subCombination.forEach((k,v)-> sortedLs.add(v));
		
		Collections.sort(sortedLs);
		
		System.out.println("---Print least subration result combination-----");
		
		subCombination.forEach((k,v)->{
			
			if(v.equals(sortedLs.get(0))) {
				
				System.out.println(k+" : "+v);
			}
		});
	}

}
