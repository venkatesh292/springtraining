package com.javainterview.practice.executable.framework;

public class Task2 implements Runnable {

	@Override
	public void run() {
		
		for(int i=20;i<30;i++) {
			
			System.out.println(Thread.currentThread().getName()+"\t"+i);
		}
		
	}

}
