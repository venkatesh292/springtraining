package com.javainterview.practice.executable.framework;

import java.util.concurrent.Callable;

public class CallableRunner implements Callable<String> {

	private String name;
	
	public CallableRunner(String name) {
		this.name = name;
	}
	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		Thread.sleep(1000);
		return "Hello :"+ this.name;
	}

}
