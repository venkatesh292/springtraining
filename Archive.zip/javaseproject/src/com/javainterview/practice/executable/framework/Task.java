package com.javainterview.practice.executable.framework;

public class Task extends Thread {

	private int number;
	
	public Task(int number) {
		this.number = number;
	}
	public void run() {
		
		System.out.println("Task "+number+" Started");
		
		for(int i =number*100; i<=number*100 +5;i++) {
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("\n"+i);
			
		}
		System.out.println(number+" Done");
	}
}
