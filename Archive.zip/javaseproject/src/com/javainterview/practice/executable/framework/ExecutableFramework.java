package com.javainterview.practice.executable.framework;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutableFramework {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		
		ExecutorService newSingleThreadExecutor = Executors.newFixedThreadPool(1);
	//	newSingleThreadExecutor.execute(new Task(1));
	//	newSingleThreadExecutor.execute(new Task(2));
//		newSingleThreadExecutor.execute(new Task(3));
		
		Future<String> submit = newSingleThreadExecutor.submit(new CallableRunner("Suresh"));
		
		List<Integer> ls = null;
		
	
		System.out.println(submit.get());
		
		newSingleThreadExecutor.shutdown();
	}
	 
	 
}
