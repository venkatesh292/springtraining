package com.javainterview.practice.reflection.example;

public class ReflectionExample {

	private String name;
	
	private int salary;
	
	public ReflectionExample() {
		
	}
	
	public void setData(String name,int salary) {
		
		this.name = name;
		this.salary = salary;
		
	}
	public void showEmpl() {
		System.out.println(this.name+","+this.salary);
	}
	
	private int geSalary() {
		return this.salary;
	}
}
