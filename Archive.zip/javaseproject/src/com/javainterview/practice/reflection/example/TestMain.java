package com.javainterview.practice.reflection.example;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class TestMain {

	public static void main(String[] args) throws Exception {
		
		ReflectionExample rf = new ReflectionExample();
		
		Class cd =Class.forName("com.javainterview.practice.reflection.example.ReflectionExample");
		
		Object newInstance = cd.newInstance();
		
		String typeName = newInstance.getClass().getTypeName();
		
		int[] n = {1,3,4,55,8,9};
		
		System.out.println(n[5]);
		
		
		Method mt = cd.getDeclaredMethod("setData",String.class,int.class);
		
		mt.invoke(newInstance,"suresh",1000);
		
		Method mt2 = cd.getDeclaredMethod("showEmpl");
		
	//	mt2.setAccessible(true);
		
		System.out.println(mt2.invoke(newInstance));
	//	Constructor<? extends ReflectionExample> declaredConstructor = rf.getClass().getDeclaredConstructor(String.class,Integer.class);
	/*	
		Class<? extends ReflectionExample> class1 = rf.getClass();
				
				
		Method declaredMethod = class1.getDeclaredMethod("setData", String.class,Integer.class);
		
		declaredMethod.invoke(rf,"Suresh",1000);
		
		Field fl = class1.getDeclaredField("name");
		fl.setAccessible(true);
		
		fl.set(rf,"Ganesh");
		*/
		

	}

}
