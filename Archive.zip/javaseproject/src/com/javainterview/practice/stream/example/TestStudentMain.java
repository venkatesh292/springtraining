package com.javainterview.practice.stream.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class TestStudentMain {

	public static void main(String[] args) {

		List<Student> studentList = Arrays.asList(new Student[] {
				new Student("suresh",
						Arrays.asList(new Marks[] { new Marks("Maths", "100"), new Marks("English", "100") })),
				new Student("ganesh",
						Arrays.asList(new Marks[] { new Marks("English", "100"), new Marks("English", "100") })),
				new Student("gowrish",
						Arrays.asList(new Marks[] { new Marks("English", "100"), new Marks("English", "100") }))
				});
		
		List<String> marks = studentList.stream().map(st1->{
			List<String> mrk = new ArrayList<>();
			for (Marks mark :st1.getMarks()) {
				
				mrk.add(mark.getMark());
			}
			return mrk;
					}).flatMap(st1->st1.stream()).collect(Collectors.toList());
	
		System.out.println(marks);
	}

}
