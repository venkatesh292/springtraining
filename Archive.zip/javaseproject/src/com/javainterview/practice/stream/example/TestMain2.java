package com.javainterview.practice.stream.example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class TestMain2 {

	public static void main(String[] args) {
		
		List<Employee> empList = Arrays.asList(new Employee[] {new Employee("ganesh","Ankola",1000),
				new Employee("gorish","kumta",2000),new Employee("goutha","kumta",500),new Employee("goutha","kumta",500)});
		
		
		int sum = empList.stream().map(Employee::getSalary).mapToInt(Integer::intValue).sum();
		
		Employee emp = empList.stream().filter(emp1 -> emp1.getName().equalsIgnoreCase("gorish")).findAny().orElse(new Employee());
		
		

	}

}
