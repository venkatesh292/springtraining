package com.javainterview.practice.stream.example;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s= "xdddd";
		
		
		List<Employee> empList = Arrays.asList(new Employee[] {new Employee("ganesh","Ankola",1000),
				new Employee("gorish","kumta",2000),new Employee("goutha","kumta",500),new Employee("goutha","kumta",500)});
		
		List<String> nameList = empList.stream().filter(emp->emp.getName().startsWith("g") && emp.getSalary()>1000).map(Employee::getName).collect(Collectors.toList());
		
		
		
		System.out.println(nameList);
		
		System.out.println("--------------Find the sum of salary---------");
		int sum =empList.stream().map(f-> f.getSalary()).mapToInt(Integer::intValue).sum();
		
		System.out.println(sum);
		
		
		System.out.println("------------Find the perticular employee----------");
		Employee emp = empList.stream().filter(f->f.getName().equalsIgnoreCase("ganesh")).findAny().orElse(null);
		
		System.out.println(emp);
		
		System.out.println("--------Print salry of the perticular person-----------");
		
		int salary = empList.stream().filter(f->f.getName().equalsIgnoreCase("Ganesh")).map(k->k.getSalary()).findAny().orElse(null);
		
		System.out.println(salary);
		
		System.out.println("----------print the salary to arrayList-----------");
	   List<Integer> empSalary = empList.stream().map(f->f.getSalary()).collect(Collectors.toList());
	   
	   System.out.println(empSalary);
	   
	   System.out.println("--------------Convert list to Map------------");
	   Map<Integer,String> empMap = empList.stream().collect(Collectors.toMap(Employee::getSalary,Employee::getName,(oldValu1,newValu1)->oldValu1,LinkedHashMap::new));
	   
	   System.out.println(empMap);
	   
	   
	}

}
