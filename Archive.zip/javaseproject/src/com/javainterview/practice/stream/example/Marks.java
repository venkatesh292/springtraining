package com.javainterview.practice.stream.example;

public class Marks {

	private String subject;
	private String mark;
	
	public Marks(String subject, String mark) {
		super();
		this.subject = subject;
		this.mark = mark;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMark() {
		return mark;
	}

	public void setMark(String mark) {
		this.mark = mark;
	}

	@Override
	public String toString() {
		return "Marks [subject=" + subject + ", mark=" + mark + "]";
	}
	
	
}
