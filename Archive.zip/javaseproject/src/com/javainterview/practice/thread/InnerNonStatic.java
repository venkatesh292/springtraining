package com.javainterview.practice.thread;

public class InnerNonStatic {

	int i =10;
	int j =20;
	static int k =30;
	public class InnerClass{
	
	   
		
		public void showDetails() {
			
			System.out.println("i value is: "+ i);
			System.out.println("j value is: "+ j);
			System.out.println("k value is: "+ k);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		new InnerNonStatic().new InnerClass().showDetails();
		
	}

}
