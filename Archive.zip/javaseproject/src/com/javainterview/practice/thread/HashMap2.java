package com.javainterview.practice.thread;

import java.util.Map;

public class HashMap2 implements Runnable {

	Map<String,Integer> map;
	
	public HashMap2(Map<String,Integer> map) {
		
		this.map = map;
		new Thread(this,"HashMap2").start();
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		
		try {
			System.out.println("Helper2 is sleeping");
			
			Thread.sleep(4000);
			map.put("two",2);
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
