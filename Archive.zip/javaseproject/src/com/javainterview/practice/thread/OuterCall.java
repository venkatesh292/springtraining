package com.javainterview.practice.thread;

public class OuterCall {

	public int i =10;
	public static int j =20;
	
	public static  class InnerClass{
		
		static int h=0;
		int kl=0;
		
	public void showResult() {
		OuterCall outer = new OuterCall();
		
		System.out.println("i value is: "+ outer.i);
		
		System.out.println("j value is: "+ j);
	}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         new OuterCall.InnerClass().showResult();
	}

}
