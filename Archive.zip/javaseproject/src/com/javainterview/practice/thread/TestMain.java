package com.javainterview.practice.thread;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<String,Integer> map = new ConcurrentHashMap<String, Integer>();
				
				// Collections.synchronizedMap(new HashMap<String,Integer>());
		
		
		HashMap1 hasmap1 = new HashMap1(map);
		
		HashMap2 hasMap2 = new  HashMap2(map);
		
		HashMap3 hasMap3 = new  HashMap3(map);
		
	map.forEach((k,v)->System.out.println(k +","+ v));

	}

}
