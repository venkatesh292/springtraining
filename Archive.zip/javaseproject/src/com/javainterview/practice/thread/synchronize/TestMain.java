package com.javainterview.practice.thread.synchronize;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestMain {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		NumberPrint number = new NumberPrint();
		
	//	ExecutorService executorService = Executors.newSingleThreadExecutor();
		
		ExecutorService executorService = Executors.newFixedThreadPool(2);
		
		executorService.execute(new NumberPrintThread(number, "odd"));
		executorService.execute(new NumberPrintThread(number, "even"));
		
		executorService.shutdown();
	}

}
