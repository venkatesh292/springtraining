package com.javainterview.practice.thread.synchronize;

public class NumberPrintThread extends Thread {

	private NumberPrint number;
	private String type;
	
	public NumberPrintThread(NumberPrint number,String type) {
		this.number = number;
		this.type = type;
		
	}
	
	public void run() {
	   number.printNumber(type,10);
	}
}
