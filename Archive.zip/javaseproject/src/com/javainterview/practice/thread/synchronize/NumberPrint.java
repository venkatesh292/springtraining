package com.javainterview.practice.thread.synchronize;

public class NumberPrint {

	public synchronized void printNumber(String type, int number) {
		
		int n = 1;
			
			if("even".equals(type)) {
				
				while(n<=number) {
				if((n%2) == 0) System.out.println(n);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				n++;
			   }
			}else {
				while(n<=number) {
				if((n%2) != 0) System.out.println(n);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				n++;
			  }
				
			}
		}

}
