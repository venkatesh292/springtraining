package com.javainterview.practice.thread;

import java.io.File;
import java.io.FileReader;

public class Filereader2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("/Users/venkatesh.nayak/Desktop/file1.txt");
		
		try {
			FileReader fr = new FileReader(file);
			int i =0;
			while((i=fr.read()) != -1) {
				System.out.println((char)i);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		Byte b = new Byte("28");
		double dd = b.doubleValue();
		
		System.out.println(dd);
	}

}
