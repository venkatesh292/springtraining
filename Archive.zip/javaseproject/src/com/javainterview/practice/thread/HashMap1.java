package com.javainterview.practice.thread;

import java.util.Map;

public class HashMap1 implements Runnable {
	Map<String,Integer> map;
	
	public HashMap1(Map<String,Integer> map) {
		
		this.map = map;
		new Thread(this,"HashMap1").start();
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
			System.out.println("Helper1 is sleeping");
			
			Thread.sleep(3000);
			map.put("One",1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
