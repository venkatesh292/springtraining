package com.javainterview.practice.thread;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;

public class FileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file = new File("/Users/venkatesh.nayak/Desktop/file1.txt");
		
		try {
			
			DataInputStream dis = new DataInputStream(new FileInputStream(file));
			
			for(int i =0; i<=file.length(); i++) {
				
				int num = dis.read();
				System.out.println(num);
			}
			
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
