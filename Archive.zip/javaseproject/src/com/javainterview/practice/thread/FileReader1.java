package com.javainterview.practice.thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class FileReader1 {

	public static void main(String[] args) {
		
		File file = new File("/Users/venkatesh.nayak/Desktop/file1.txt");
		File file2 = new File("/Users/venkatesh.nayak/Desktop/file2.txt");
		try {
		 BufferedReader br = new BufferedReader(new FileReader(file));
		FileWriter fw = new FileWriter(file2);
		 String st = null;
		 while((st=br.readLine()) != null) {
			 
			 System.out.println(st);
			 fw.write(st);
			 
			
		 }
		 
		 fw.close();
		 br.close();
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
