package com.javainterview.practice.thread.producer;

public class ProducerThread implements Runnable {

	Generator gen;
	
	public ProducerThread(Generator gen) {
		this.gen = gen;
		Thread t = new Thread(this,"Producer");
		t.start();
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int i=0;
		while(true) {
			gen.putVal(i++);	
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
	
}
