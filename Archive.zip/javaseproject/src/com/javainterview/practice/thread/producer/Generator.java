package com.javainterview.practice.thread.producer;

public class Generator {

	private int val;
	private boolean valueSet = false;
	
	public  synchronized void putVal(int val) {
		
		while(valueSet) {
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		}
			System.out.println("PUT\t"+ val);
			this.val = val;
			valueSet = true;
			notify();
		
	}
	
	public synchronized int getVal() {
		
		while(!valueSet) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		valueSet =false;
		notify();
		return this.val;
		
	}
}
