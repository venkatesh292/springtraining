package com.javainterview.practice.thread.producer;

public class ConsumerThread implements Runnable{

	Generator gen;
	
	public ConsumerThread(Generator gen) {
		this.gen = gen;
		Thread t = new Thread(this,"Consumer");
		t.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(true) {
		
			System.out.println("GET\t"+ gen.getVal());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
