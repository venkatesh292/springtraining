package com.javainterview.practice.datastructure.example;

public class QuickSort {
	
	void quickSort(int[] a,int first,int last) {
		
		int i,j,temp,pivot;
		
		if(first<last) {
		
			pivot = first;
			i = first;
			j = last;
			
			while(i<j) {
				
				while((a[i] <= a[pivot]) && i<last) 
					i++;		
				while(a[j]>= a[pivot])j--;
				
				if(i<j) {
					
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
				}
			}
			
			temp = a[pivot];
			a[pivot] = a[j];
			a[j] = temp;
			
			quickSort(a,first,j-1);
			quickSort(a,j+1, last);
		}
		
		for(int k=0;k<a.length;k++) {
		System.out.println(a[k]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuickSort qs = new QuickSort();
		int n[] = {1,5,3,9,6,8};
		
		qs.quickSort(n,0,n.length-1);
	}

}
