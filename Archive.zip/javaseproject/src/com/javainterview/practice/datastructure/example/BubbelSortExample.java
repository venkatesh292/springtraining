package com.javainterview.practice.datastructure.example;

public class BubbelSortExample {

	public static void main(String[] args) {
		
		int n[] = {1,5,3,9,6,8};
		
		int temp =0;
		
		for(int i =0;i<n.length;i++) {
			for(int j=0; j<n.length;j++) {
			
				if(n[i]<n[j]) {
				temp =n[i];
				n[i] = n[j];
				n[j]= temp;
				}
			}
		}

		for(int i=0;i<n.length;i++) {
		System.out.println(n[i]);
		}
	}

}
