package com.javainterview.practice.datastructure.example;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class MergeSortExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "naveen, suresh, geanes";
		List<String> collect = Pattern.compile(",").splitAsStream(s).filter(x->!x.equals("naveen")).collect(Collectors.toList());
		
		System.out.println(collect);
		

	}

}
