package com.javainterview.practice.comparable.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> empList = Arrays.asList(new Employee[]{new Employee(10,"suresh","1000"),
			                                    new Employee(6,"ganesh","1000"),
			                                    new Employee(2,"madesh","1000"),
			                                    new Employee(11,"gourish","1000")});
		
		Collections.sort(empList);
		
		System.out.println(empList);
				
	}

}
