package com.javainterview.practice.comparable.example;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class HashMainTest {

	public static void main(String[] args) {
		
		Map<HashTest,Integer> map = new HashMap<>();
		
		HashTest t1 = new HashTest(1);
		
		HashTest t2 = new HashTest(1);
		
		map.put(t1,1);
		map.put(t2,1);
	
		System.out.println(map.size());
		
		map.forEach((k,v)-> System.out.println(k+","+ v));
		
		Set p = new HashSet();
		
		System.out.println(t1.hashCode());
		
		System.out.println(t2.hashCode());
		
		p.add(t1);
		p.add(t2);
		
		System.out.println(p.size());
		
	}
}
