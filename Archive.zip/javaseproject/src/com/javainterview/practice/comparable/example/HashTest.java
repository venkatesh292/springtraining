package com.javainterview.practice.comparable.example;

public class HashTest {

	private int x;
	
	HashTest(int x) {
		this.x = x;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x;
		return result;
	}



	@Override
	public String toString() {
		return "HashTest [x=" + x + "]";
	}
	
	
}
