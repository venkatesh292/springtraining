package com.javainterview.practice.clonable.shalowclone;

public class TestMain {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		Address address = new Address("Ankola");
		Employee empl = new Employee(12,"Suresh","1000", address);
		
		Employee emp = empl.clone();
		
		System.out.println("Original Object\t"+empl.hashCode()+ "Address: "+ empl.getAddress().hashCode());
		
		
		System.out.println("Clonned Object\t"+ emp.hashCode()+" Address: "+ emp.getAddress().hashCode());
		
		
	}

}
