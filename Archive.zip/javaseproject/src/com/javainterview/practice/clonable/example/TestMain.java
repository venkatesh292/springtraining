package com.javainterview.practice.clonable.example;

import java.util.HashMap;
import java.util.HashSet;

public class TestMain {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		Employee emp = new Employee(12,"Ganesh","5000");
		
	//	System.out.println("Actual Object : "+ emp.hashCode());
		
	//	Employee emp2 = (Employee)emp.clone();
		
		Employee emp2 = new Employee(12,"Ganesh1","5000");
		
	//	System.out.println((emp.equals(emp2)));
	//	System.out.println("Actual Object : "+ emp.hashCode());
		
	//	System.out.println("Clonned Object: "+ emp2.hashCode());
		
		 HashSet<Employee> employees = new HashSet<Employee>();
	        employees.add(emp);
	        System.out.println(employees.contains(emp2));
	        
	        System.out.println("Actual Object : "+ emp.hashCode());
	        
	        System.out.println("Actual Object : "+ emp2.hashCode());
	        
	        Integer i1 = new Integer(1);
	        Integer i2 = new Integer(1);
	        
	        HashMap<Integer,String> map = new HashMap<Integer, String>();
	        map.put(i1,"one");
	        map.put(i2, "one");
	        
	        System.out.println(map.size());
	}

}
