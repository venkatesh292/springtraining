package com.javainterview.practice.clonable.example;

public interface B {

	void show();
}
