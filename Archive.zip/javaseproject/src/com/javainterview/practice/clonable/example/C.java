package com.javainterview.practice.clonable.example;

public class C implements A, B {

	@Override
	public void show() {
 System.out.println("Hello");
	}

}
