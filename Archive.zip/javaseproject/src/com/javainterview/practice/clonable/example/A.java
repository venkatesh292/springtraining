package com.javainterview.practice.clonable.example;

public interface A {

	void show();
}
