package com.javainterview.practice.comparator.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ComparatorTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> empList = Arrays.asList(new Employee[]{new Employee(10,"suresh","1000"),
                new Employee(6,"madesh","1000"),
                new Employee(6,"ganesh","1000"),
                new Employee(11,"gourish","1000")});
		
		Collections.sort(empList, (p, v)-> p.getName().compareTo(v.getName()));
		
		Collections.sort(empList,(p, v)-> p.getId()<v.getId()? -1:p.getId()>v.getId()?1:0);
		
		
		
		System.out.println(empList);
		
	}

}
