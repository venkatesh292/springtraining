package com.javainterview.practice.example;

public class TestClass {

	public static void addShow(int a, int b) {
		
		System.out.println("Values of int");
	}
	
	public static void addShow(Integer a, Integer b) {
		
		System.out.println("Values of Integer");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		addShow(2,4);
	}

}
