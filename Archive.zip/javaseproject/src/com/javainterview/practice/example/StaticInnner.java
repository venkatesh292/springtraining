package com.javainterview.practice.example;

public class StaticInnner {

	int n =20;
	static int k=30;
	public static class InnerClass1{
		
		
		public void add() {
			
			
			
			StaticInnner st = new StaticInnner();
			System.out.println(st.n);
		
			
		
			}
	}
	
	public class innernon{
		
		
		public void add() {
			
			System.out.println(n+","+k);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		new StaticInnner.InnerClass1().add();
		
		new StaticInnner().new innernon().add();
	}

}
