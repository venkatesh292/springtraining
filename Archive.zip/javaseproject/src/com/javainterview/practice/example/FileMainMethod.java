package com.javainterview.practice.example;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;

import javax.imageio.ImageIO;

public class FileMainMethod {

	/*
	static {
		try {
		throw new FileNotFoundException();
		}catch(FileNotFoundException ex) {
			ex.printStackTrace();
		}
	}
	*/
	
	int method1() {
		
		return(true?null:0);
	}
	public static void main(String[] args) {
	/*	
		File file = null;
		try {
		
			file = new File("/Users/venkatesh.nayak/Desktop/Data_backup/PASSPORT/myimage.png");
			
			
			  BufferedImage read = ImageIO.read(file);
		//	  System.out.println(read);
			  ImageIO.write(read,"bmp", new File("//Users//venkatesh.nayak//Desktop//Data_backup//PASSPORT//imagemine.bmp"));
			  
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		*/
		FileMainMethod fl = new  FileMainMethod();
		fl.method1();
		

	}

}
