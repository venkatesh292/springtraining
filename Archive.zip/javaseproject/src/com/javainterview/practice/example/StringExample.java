package com.javainterview.practice.example;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.javainterview.practice.comparable.example.Employee;

public class StringExample {

	public static void StreamExa() {

		List<Employee> empList = Arrays
				.asList(new Employee[] { new Employee(10, "suresh", "1000"), new Employee(6, "ganesh", "1000"),
						new Employee(2, "madesh", "1000"), new Employee(11, "gourish", "1000") });

	//	Collections.sort(empList);
		
	//	System.out.println(empList);
		
		
	}

	public static void StreamExa1() {

		String names = "venkatesh,Suresh,Ganesh,Girish";

		List<String> nameList = Arrays.stream(names.split(",")).map(String::trim).collect(Collectors.toList());

		nameList.forEach(System.out::println);

		System.out.println("********************************************");

		List<String> listName = Arrays.asList("venkatesh", "Suresh", "Ganesh", "Girish");

		String allListName = String.join(",", listName);

		System.out.println(allListName);
	}

	public static void main(String[] args) {

		StreamExa();
	}

}
