package com.javainterview.practice.example;

public class StaticBlock {

private int n;
private static int k;
	static
	{
		
		StaticBlock st = new  StaticBlock();
		st.n =10;
		k=10;
		int f =30;
		int  g=90;
		
	}
	
	{
		
		n =20;
		k=30;
	}
	
	public static void main(String[] args) {
		
	}
}
