package com.javainterview.practice.example;

import java.util.Arrays;
import java.util.Stack;

public class PersistantJava {

	public static void main(String[] args) {
		
		System.out.println(Double.MIN_VALUE);
		System.out.println(Math.min(Double.MIN_VALUE,0.0d));
		
		System.out.println((int)Math.pow(2, 3));
		
		String  mystring = "India is My Country";
		
		String[] arrString = mystring.split(" ");
		
			Stack<String> st = new Stack<>();
			
			for (int i = 0; i < arrString.length; i++) {
				
				st.push(arrString[i]);
			}
			int size = st.size();
	     for (int i = 0; i<size; i++) {
	    
	    	 System.out.println(st.pop());
			
		}  

	}

}
