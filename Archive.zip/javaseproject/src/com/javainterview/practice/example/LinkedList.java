package com.javainterview.practice.example;

public class LinkedList {

	public class Node{
		
		int data;
		Node next;
		
		public Node(int data) {
			this.data = data;
			this.next = null;
		}
	}
		Node head = null;
		Node tail = null;
		public void addNode(int item) {
			
			Node newNode = new Node(item);
			
			if(head == null) {
				
				head = newNode;
				tail = newNode;
			}else {
				tail.next= newNode;
				tail = newNode;
			}
		}
		
		public void displayNode() {
			
			Node curreNode = head;
			
			if(head == null) {
				System.out.println("Empty Lisked List");
			}else {
				while(curreNode != null) {
					System.out.println(curreNode.data);
					curreNode = curreNode.next;
				}
			}
		}
		
		public void addNodeLast(int data) {
			
			Node n = new Node(data);
			if(head == null) {
				head = n;
				tail = n;
			}else {
			  
			Node nextNode = head;
				while(nextNode.next != null) {
					nextNode = nextNode.next;
				}
			  nextNode.next=n;
			}
			
				}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList ls = new  LinkedList();
		
		ls.addNode(1);
		ls.addNode(4);
		ls.addNode(5);
		ls.addNode(8);
		ls.addNode(10);
		
		ls.addNodeLast(2);
		
		
		ls.displayNode();

	}

}
