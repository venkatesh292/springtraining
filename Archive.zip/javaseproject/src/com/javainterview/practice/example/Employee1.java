package com.javainterview.practice.example;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class Employee1 implements Externalizable {

	private String empName;
	private String empCity;
	
	
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpCity() {
		return empCity;
	}

	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {
		// TODO Auto-generated method stub
		
		out.writeObject(this.getEmpName());
		out.writeObject(this.getEmpCity());
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		this.empName = (String) in.readObject();
		this.empCity = (String) in.readObject();
	}

	@Override
	public String toString() {
		return "Employee1 [empName=" + empName + ", empCity=" + empCity + "]";
	}
	
}
