package com.javainterview.practice.example;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SynchronizedHashMapExample {
	
	
	public static void main(String[] args) {
		
		Map<Integer,String> map = new HashMap<Integer,String>();
		
		map.put(1,"suresh");
		map.put(4,"suresh1");
		map.put(6,"suresh2");
		map.put(8,"suresh3");

	//	Map<Integer,String> map2 = Collections.synchronizedMap(map);
		
		
		ConcurrentHashMap<Integer, String> map2 = new ConcurrentHashMap<Integer,String>(map); 
		
		int i=0;
		for(Map.Entry<Integer,String> map1 : map2.entrySet()) {
		
			if(i==1) {
				map2.put(9,"Ganesh");
			}
			System.out.println(map1.getKey()+": "+map1.getValue());
			i++;
		}
		
	
		
	}

}
