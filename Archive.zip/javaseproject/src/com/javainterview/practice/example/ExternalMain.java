package com.javainterview.practice.example;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ExternalMain {

	public static void main(String[] args) {
		
		Employee1 emp1 = new Employee1();
		
		emp1.setEmpName("Suresh");
		
		emp1.setEmpCity("Ankola");
		
		try {
			FileOutputStream fis = new FileOutputStream(new File("/Users/venkatesh.nayak/Desktop/externalfile.txt"));
			
			ObjectOutputStream ous = new ObjectOutputStream(fis);
			
		    ous.writeObject(emp1);	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
