package com.springbatchlistener.batchconfig;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.springbatchlistener.listener.JobCompletionListener;
import com.springbatchlistener.steps.Processor;
import com.springbatchlistener.steps.Reader;
import com.springbatchlistener.steps.Writer;

@Configuration
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job processJob() {
		
		return jobBuilderFactory.get("processJob")
				.incrementer(new RunIdIncrementer())
				.listener(new JobCompletionListener())
				.flow(OrderStep()).end().build();
		
	}
	
	@Bean
	public Step OrderStep() {
		
		return stepBuilderFactory.get("OrderStep")
				.<String,String>chunk(1)
				.reader(new Reader())
				.processor(new Processor())
				.writer(new Writer()).build();
	}
	
}
