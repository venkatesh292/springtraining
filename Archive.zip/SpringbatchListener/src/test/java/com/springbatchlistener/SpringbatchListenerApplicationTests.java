package com.springbatchlistener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbatchListenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
