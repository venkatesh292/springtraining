package com.filespringintegration.integrationconfig;

import java.io.File;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.FileWritingMessageHandler;
import org.springframework.integration.file.filters.AcceptOnceFileListFilter;
import org.springframework.integration.file.filters.CompositeFileListFilter;
import org.springframework.integration.file.filters.ExpressionFileListFilter;
import org.springframework.integration.file.filters.FileListFilter;
import org.springframework.integration.file.filters.SimplePatternFileListFilter;

@Configuration
@EnableIntegration
public class SringIntegrationConfig {

	@Bean
    @InboundChannelAdapter(value = "fileInputChannel", poller = @Poller(fixedDelay = "1000"))
    public FileReadingMessageSource fileReadingMessageSource() {
        CompositeFileListFilter<File> filter=new CompositeFileListFilter<>();
        FileListFilter<File> flt = new SimplePatternFileListFilter("*.log");
        
  //      FileListFilter<File> flt2 = new AcceptOnceFileListFilter<>();
     
        List<FileListFilter<File>> lis = new ArrayList<>();
        
        lis.add(flt);
    //    lis.add(flt2);
        
        filter.addFilters(lis);
       
        FileReadingMessageSource readder = new FileReadingMessageSource();
        readder.setDirectory(new File("/Users/venkatesh.nayak/Desktop/logs"));
        readder.setFilter(filter);
        return readder;
    }
	
	  @Bean
	    @ServiceActivator(inputChannel = "fileInputChannel")
	    public FileWritingMessageHandler fileWritingMessageHandler() {
	        FileWritingMessageHandler writter = new FileWritingMessageHandler(new File("/Users/venkatesh.nayak/Desktop/logs/imported"));
	        writter.setAutoCreateDirectory(true);
	        writter.setExpectReply(false);
	        return writter;
	    }
}
