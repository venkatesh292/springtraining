package com.springproject.dao.jdbctemplate.xml;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("jdbctemplateconfiguration.xml");
		
		EmployeeService employee = context.getBean("employeeServiceImpl",EmployeeServiceImpl.class);
		
	//	System.out.println("------------Getting all the records-------------------");
		 
	//	List<Employee> empList = employee.getAllEmployee();
		  
	//	System.out.println(empList);

		int count = employee.saveEmployee(new Employee(10,"Shivkumar Prasad",10000));
		
		System.out.println("Total number of rows inserted : "+ count);
		
	}

}
