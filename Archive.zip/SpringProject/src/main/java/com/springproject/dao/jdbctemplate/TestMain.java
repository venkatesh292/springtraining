package com.springproject.dao.jdbctemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.naming.directory.InvalidAttributesException;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.springproject.dao.jdbctemplate");

		context.refresh();

		EmplService emplService = context.getBean("emplServiceImpl", EmplServiceImpl.class);
/*
		int count = employeeDAO.saveEmployee(new Employee(6,"Suhas",6000));

		System.out.println("Total rows inserted "+ count);

		 int count = employeeDAO.updateEmployee(4,"kumar");

		 System.out.println("Number of rows updated : "+ count);

		int count1 = employeeDAO.deleteEmployee(4);

		System.out.println("Number of rows deleted : " + count1);

		System.out.println("------------Getting all the records-------------------");

		List<Employee> empList = employeeDAO.getAllEmployee();

		System.out.println(empList);

		System.out.println("----------------------------Getting Single record-----------------------------------");
		
		Employee employee = employeeDAO.getEmployee(2);

		System.out.println(employee);
		*/
		
		int count = 0;
		try {
		//	Employee employee= null;
			count = emplService.saveEmployee(new Employee(10,"Shivkumar chandra",10000));
	//		count = emplService.saveEmployee(employee);
		//	System.out.println("Total number of rows inserted : "+ count);
		} catch (InvalidAttributesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	//	List<Employee> allEmployee = employeeService.getAllEmployee();

	//	System.out.println(allEmployee);
		
	/*	
		Employee employee = new Employee(6,"chandrashekar",4000);
		Employee empl = new Employee(7,"ramkumar verma",8000);
		List<Employee> employeeList = new ArrayList<Employee>();
		
		employeeList.add(employee);
		employeeList.add(empl);
		int count = employeeService.updateMultiEmployee(employeeList);
		
		System.out.println("total rows updated: "+ count);
		*/
	}

}
