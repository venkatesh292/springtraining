package com.springproject.aop.xml;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("empaop.xml");
		
		Employee emp = context.getBean("employee", Employee.class);
		
		System.out.println(emp.getEmployeeDetails());
	}

}
