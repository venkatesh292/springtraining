package com.springproject.aop.example;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmployDAOImpl implements EmployDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int saveEmployee(Employee employee) {

		String sql = "insert into employee(EMPLOYEE_NAME,EMPLOYEE_SALARY) values(?,?)";

		int count = jdbcTemplate.update(sql, employee.getEmployeeName(), employee.getEmployeeSalary());

		return count;
	}

	@Override
	public int updateEmployee(int id, String name) {

		String sql = "update employee set employee_name = ? where id= ?";

		int count = jdbcTemplate.update(sql, name, id);

		return count;
	}

	@Override
	public int deleteEmployee(int id) {

		String sql = "delete from employee where id = ?";

		return jdbcTemplate.update(sql, id);

	}

	@Override
	public Employee getEmployee(int id) {

		String sql = "select * from employee where id = ?";

		try {
		return jdbcTemplate.queryForObject(sql, new Object[] { id }, (resultset,
				rowCount) -> new Employee(resultset.getInt(1), resultset.getString(2), resultset.getInt(3)));
		
	 } catch (EmptyResultDataAccessException e) {
	        return null;
	    }
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub

		String sql = "select * from employee";

		try {
		List<Employee> empList = jdbcTemplate.query(sql, (resultset, rowCount) -> new Employee(resultset.getInt(1),
				resultset.getString(2), resultset.getInt(3)));
		return empList;
		
		}catch (EmptyResultDataAccessException e) {
			
	        return null;
	    }


	}

	@Override
	public int updateMultiEmployee(List<Employee> employee) {
		// TODO Auto-generated method stub
		String sql = "update employee set employee_name = ? where id= ?";
		
		int[] batchUpdate = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				
				ps.setString(1,employee.get(i).getEmployeeName());
				ps.setInt(2,employee.get(i).getEmployeeId());
				
			}
			
			@Override
			public int getBatchSize() {
				// TODO Auto-generated method stub
				return employee.size();
			}
		});
		
		int totalRowsupdated =0;
		for (int i : batchUpdate) {
			
			totalRowsupdated += 1;
		}
		
		return totalRowsupdated;
	}

}
