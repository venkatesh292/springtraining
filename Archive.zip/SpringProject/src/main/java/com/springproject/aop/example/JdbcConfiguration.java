package com.springproject.aop.example;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@PropertySource("classpath:mysqldb.properties")
@ComponentScan(basePackages = "com.springproject.aop.example")
@EnableTransactionManagement(proxyTargetClass = true)
@EnableAspectJAutoProxy
public class JdbcConfiguration {
				
	@Value("${db.mysql.driverClassName}")		
	private String driverClassName;
	
	@Value("${db.mysql.url}")
	private String url;
	
	@Value("${db.mysql.username}")
	private String userName;
	
	@Value("${db.mysql.password}")
	private String password;
	
	private JdbcTemplate jdbcTemplate;
	
	private DriverManagerDataSource datasource;
	
	@Bean(name = "jdbcTemplate")
	public JdbcTemplate getJdbcTemplate() {
		
		
		datasource = new DriverManagerDataSource();
		
		datasource.setDriverClassName(driverClassName);
		datasource.setUrl(url);
		datasource.setUsername(userName);
        datasource.setPassword(password);
        
        jdbcTemplate = new JdbcTemplate(datasource);
        
        return jdbcTemplate;
	}
	
	@Bean
     public PlatformTransactionManager getTransactionManager() {
		
		return new DataSourceTransactionManager(datasource);
		
	}
	
}
