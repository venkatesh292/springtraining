package com.springproject.aop.example;



import java.util.Arrays;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggingAspect {

	private static final Logger LOGGER = LogManager.getLogger(LoggingAspect.class.getName());
	
	/*
	@Before("execution(* com.springproject.dao.jdbctemplate.EmployeeServiceImpl.saveEmployee(..))")
	public void before(JoinPoint joinpoint) {
		
		Object[] arr = joinpoint.getArgs();
		
		LOGGER.info("Entering method: "+joinpoint.getSignature().getName()+"Input parameter: "+ arr[0]);
	}
	
	@After("execution(* com.springproject.dao.jdbctemplate.EmployeeServiceImpl.saveEmployee(..))")
	public void after(JoinPoint joinPointer) {
		
		LOGGER.info("Completed excecution: "+joinPointer.getSignature().getName());
	}
	
	@AfterReturning(pointcut = "execution(* com.springproject.dao.jdbctemplate.EmployeeServiceImpl.saveEmployee(..))", returning = "result")
	public void afterReturn(JoinPoint joinpoint, Object result) {
		
		LOGGER.info("Completed execution of the method: "+ joinpoint.getSignature().getName()+" with result as : "+ result);
	}
	
	@AfterThrowing(pointcut = "execution(* com.springproject.dao.jdbctemplate.EmployeeServiceImpl.saveEmployee(..))", throwing = "exception")
	public void afterThrowing(JoinPoint joinpoint,Exception exception) {
	
		LOGGER.info("Exception occured while ivoking method: "+ joinpoint.getSignature().getName()+"Exception : "+ exception.getMessage());
	}
	*/
	
	//@Around("execution(* *.*Employee(..))")
	@Around("execution(* *.*Employee(..))")
	public Object around(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
		
		Object result = null;
		Object[] arr = proceedingJoinPoint.getArgs();
		
		LOGGER.info(proceedingJoinPoint.getSignature().getName()+" Input parameters "+arr[0]);
		if(arr.length >0) {
	 result = proceedingJoinPoint.proceed(arr);
		}
		LOGGER.info("Rsult: "+result);
		return result;
		
	}
	
}
