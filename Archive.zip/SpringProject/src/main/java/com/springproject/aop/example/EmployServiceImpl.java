package com.springproject.aop.example;

import java.util.List;

import javax.naming.directory.InvalidAttributesException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class EmployServiceImpl implements EmployService {

	@Autowired
	private EmployDAO employeeDAO;
    
	@Transactional
	public int saveEmployee(Employee employee) throws InvalidAttributesException {
		// TODO Auto-generated method stub
		if(employee != null) {
		return employeeDAO.saveEmployee(employee);
		}else {
			throw new InvalidAttributesException("Passing empty obejct referrence");
		}
	}


	@Transactional
	public int updateEmployee(int id, String name) {
		// TODO Auto-generated method stub
		return employeeDAO.updateEmployee(id, name);
	}

	@Transactional
	public int deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeDAO.deleteEmployee(id);
	}

	@Transactional(readOnly = true)
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDAO.getAllEmployee();
	}

	
	public Employee getEmployee(int id) {
		// TODO Auto-generated method stub
		return employeeDAO.getEmployee(id);
	}


	@Transactional
	public int updateMultiEmployee(List<Employee> employee) {
		// TODO Auto-generated method stub
		return employeeDAO.updateMultiEmployee(employee);
	}

}
