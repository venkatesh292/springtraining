package com.springproject.ioc.applicationcontext.filesystem;

public class Student {

	int id = 10;
	String name = "Ganesh";
	
	public Student() {
		System.out.println("Student object initialized");
	}
	public void getStudentDetails() {
		
		System.out.println("Student ID: "+ id +", Student Name: "+ name );
	}
}
