package com.springproject.bean.annotation.value;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.springproject.bean.annotation.value");
		
		context.refresh();
		
		Student student = context.getBean("student", Student.class);
		
		System.out.println(student);
		
		
	}
	
	
}
