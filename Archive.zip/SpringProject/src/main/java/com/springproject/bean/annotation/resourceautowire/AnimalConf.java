package com.springproject.bean.annotation.resourceautowire;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class AnimalConf {

	@Resource
	private Dog animal;
	
   public void showAnimalDetails() {
	   
	   animal.animalDetails();
   }
	
}
