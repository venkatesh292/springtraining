package com.springproject.bean.autowire.inject;

import org.springframework.stereotype.Component;

@Component
public class Suzuki implements Vehical {

	@Override
	public void showVehical() {
		// TODO Auto-generated method stub

		System.out.println("This is suzuki class");
	}

}
