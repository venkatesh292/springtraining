package com.springproject.bean.annotation.resourceautowire;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestHuman {

	public static void main(String[] args) {
		
		List<Human> humanList = Arrays.asList(new Human(12,"suresh"),new Human(11,"ganesh"), new Human(6,"nilesh"));
		
		System.out.println("Before Sorting");
		
		System.out.println(humanList);
		
		System.out.println("After sorting by name");
		
		humanList.sort((h1,h2)-> h1.getHumanName().compareTo(h2.getHumanName()));
		
		System.out.println(humanList);
		
		System.out.println("After sorting by age");
		
	//	humanList.sort((h1,h2)-> h1.getHumanAge()>h2.getHumanAge()?-1:h1.getHumanAge()<h2.getHumanAge()?1:0);
		
	//	System.out.println(humanList);
		
		
		Comparator<Human> humanAgeComparator = (h3,h4)->h3.getHumanAge()>h4.getHumanAge()?-1:h3.getHumanAge()<h4.getHumanAge()?1:0;
		
		Collections.sort(humanList,humanAgeComparator);
		
		System.out.println(humanList);
		
		System.out.println("Comparable");
		
		Collections.sort(humanList);
		
		System.out.println(humanList);
		
		
		
	}
}
