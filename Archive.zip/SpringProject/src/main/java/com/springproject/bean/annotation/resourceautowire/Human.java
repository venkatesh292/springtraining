package com.springproject.bean.annotation.resourceautowire;

public class Human implements Comparable<Human> {

	private int humanAge;
	private String humanName;
	
	public Human(int humanAge, String humanName) {
		super();
		this.humanAge = humanAge;
		this.humanName = humanName;
	}
	public int getHumanAge() {
		return humanAge;
	}
	public void setHumanAge(int humanAge) {
		this.humanAge = humanAge;
	}
	public String getHumanName() {
		return humanName;
	}
	public void setHumanName(String humanName) {
		this.humanName = humanName;
	}
	@Override
	public String toString() {
		return "Human [humanAge=" + humanAge + ", humanName=" + humanName + "]";
	}
	@Override
	public int compareTo(Human o) {
		
          return this.humanAge>o.humanAge?1:this.humanAge<o.humanAge?-1:0;
	}
	
	
}
