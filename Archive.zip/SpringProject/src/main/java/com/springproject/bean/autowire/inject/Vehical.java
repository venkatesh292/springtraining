package com.springproject.bean.autowire.inject;

public interface Vehical {

	void showVehical();
}
