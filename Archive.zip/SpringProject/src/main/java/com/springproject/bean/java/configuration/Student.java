package com.springproject.bean.java.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration("student")
public class Student {

	@Bean(name="marks")
	public Marks marks() {
		
		Marks marks = new Marks();
		marks.setMarks1(100);
		marks.setMarks2(200);
		marks.setMarks3(300);
		
		return marks;
	}
	
	public void showStudent() {
		System.out.println("This is student class ");
	}
}
