package com.springproject.bean.multipropertyresources.autowire;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class MailConfig {

	@Value("${mail.smtp.host}")
	private String smtpHost;
	
	@Value("${mail.smtp.port}")
	private String port;
	
	@Value("${mail.smtp.username}")
	private String userName;
	
	@Value("${mail.smtp.password}")
	private String password;
	
	public MailConfig() {
		super();
		System.out.println("Mail Class Constructor called");
	}
	
	public String getSmtpHost() {
		return smtpHost;
	}
	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void getMailConfigDetails() {
		
		System.out.println("SMTP HOST: "+ this.getSmtpHost());
		System.out.println("PORT: "+this.getPort());
		System.out.println("User Name: "+ this.getUserName());
		System.out.println("Password: "+ this.getPassword());
	}
	
}
