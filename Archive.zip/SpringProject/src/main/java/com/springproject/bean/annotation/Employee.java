package com.springproject.bean.annotation;

import org.springframework.stereotype.Component;

@Component
public class Employee {

	private int emplId = 10;
	private String empName = "Ganesh";
	private int empSalary = 10000;
	
	public int getEmplId() {
		return emplId;
	}
	public void setEmplId(int emplId) {
		this.emplId = emplId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Employee [emplId=" + emplId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
	
	
}
