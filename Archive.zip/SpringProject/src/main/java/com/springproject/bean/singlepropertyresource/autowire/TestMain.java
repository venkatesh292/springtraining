package com.springproject.bean.singlepropertyresource.autowire;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.springproject.bean.singlepropertyresource.autowire");
		
		context.refresh();
		
		DataBaseConfig dbConfig = context.getBean("dataBaseConfig",DataBaseConfig.class);
		
		dbConfig.getDBConfigDetails();
		
		context.close();
	}

}
