package com.springproject.bean.autowire.inject;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Primary
@Component
public class Honda implements Vehical {

	@Override
	public void showVehical() {
		// TODO Auto-generated method stub

		System.out.println("This is Honda class");
	}

}
