package com.springproject.bean.multipropertyresources.autowire;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@ComponentScan(basePackages = "com.springproject.bean.multipropertyresources.autowire")
@PropertySources({@PropertySource("classpath:db.properties"),@PropertySource("mailconfig.properties")})
public class PropertyConfiguration {

}
