package com.springproject.bean.multipropertyresources.autowire;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(PropertyConfiguration.class);
		
		System.out.println("----------Data Base configuration details---------------");
		
		DataBaseConfig dbConfig = context.getBean("dataBaseConfig", DataBaseConfig.class);
		
		dbConfig.getDBConfigDetails();
		
		System.out.println("--------------Mail Config Details-----------------");
		
		MailConfig mailConfig = context.getBean("mailConfig", MailConfig.class);
		
		mailConfig.getMailConfigDetails();
		
		System.out.println("----Second MailConfig Bean Created-------");
		
		MailConfig mailConfig2 = context.getBean("mailConfig", MailConfig.class);
	
		mailConfig2.getMailConfigDetails();
	}

}
