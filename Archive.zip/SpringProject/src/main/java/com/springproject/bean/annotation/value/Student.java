package com.springproject.bean.annotation.value;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Student {

@Value("12")
private int studentId;

@Value("Suresh")
private String studentName;

@Value(value = "{100,200,300}")
private List<String> marks;

public int getStudentId() {
	return studentId;
}

public void setStudentId(int studentId) {
	this.studentId = studentId;
}

public String getStudentName() {
	return studentName;
}

public void setStudentName(String studentName) {
	this.studentName = studentName;
}

public List<String> getMarks() {
	return marks;
}

public void setMarks(List<String> marks) {
	this.marks = marks;
}

@Override
public String toString() {
	return "Student [studentId=" + studentId + ", studentName=" + studentName + ", marks=" + marks + "]";
}


}
