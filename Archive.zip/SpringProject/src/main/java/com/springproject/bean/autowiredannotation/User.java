package com.springproject.bean.autowiredannotation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Component;

@Component
public class User {

	@Autowired(required = false)
	private Vehical vehical;
	
	@PostConstruct
	public void init() {
		System.out.println("initializing the User bean properties");
	}
	

	public void showDetails() {
		
		vehical.showVehical();
	}
	
	@PreDestroy
	public void userDestroy() {
		System.out.println("Destorying the user bean");
	}
}
