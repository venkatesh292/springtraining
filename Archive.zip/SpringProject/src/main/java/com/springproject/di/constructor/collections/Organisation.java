package com.springproject.di.constructor.collections;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Organisation {

	private List<String> students;
	   private Set<String> depart;
	   private Map staf;
	   private Properties numberOfStudents;
	     
	public Organisation(List<String> students, Set<String> depart, Map staf, Properties numberOfStudents) {
		super();
		this.students = students;
		this.depart = depart;
		this.staf = staf;
		this.numberOfStudents = numberOfStudents;
	}

	public void getOrganizationDetails() {
		System.out.println("Students: "+ this.students);
		System.out.println("Departments: "+ this.depart);
		System.out.println("Staff: "+ this.staf);
		System.out.println("Number of students:"+ this.numberOfStudents);
	}
}
