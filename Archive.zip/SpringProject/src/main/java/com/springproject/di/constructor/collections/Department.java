package com.springproject.di.constructor.collections;

public class Department {

	private int departId;
	private String departName;
	
	public int getDepartId() {
		return departId;
	}
	public void setDepartId(int departId) {
		this.departId = departId;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	@Override
	public String toString() {
		return "Department [departId=" + departId + ", departName=" + departName + "]";
	}
	
	
}
