package com.employeeservice.service;

public class EmployeeService {

}
