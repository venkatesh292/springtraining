package com.bugtrackermvc.bugtrackermvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BugtrackermvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
