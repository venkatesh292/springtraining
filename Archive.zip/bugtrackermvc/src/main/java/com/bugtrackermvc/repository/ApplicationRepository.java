package com.bugtrackermvc.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bugtrackermvc.entity.Application;


public interface ApplicationRepository extends CrudRepository<Application,Long> {
	
	
	@Query(value = "select a from Application a where name like %?1%")
	List<Application> findByAppsName(String keyword);
	
}
