package com.bugtrackermvc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bugtrackermvc.entity.Release;

public interface ReleaseRepository extends CrudRepository<Release,Long> {

	@Query(value = "select a from Release a where description like %?1%")
	List<Release> findByRelease(String keyword);
}
