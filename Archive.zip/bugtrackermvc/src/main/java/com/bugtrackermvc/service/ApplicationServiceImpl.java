package com.bugtrackermvc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bugtrackermvc.entity.Application;
import com.bugtrackermvc.repository.ApplicationRepository;

@Service
public class ApplicationServiceImpl implements ApplicationService {

	@Autowired
	private ApplicationRepository applicationRepository;

	@Override
	public List<Application> findAll() {

		
		return (List<Application>) applicationRepository.findAll();
	}

	public Application findById(Long id) {

		Optional<Application> findById = applicationRepository.findById(id);

		return findById.isPresent() ? findById.get() : null;
	}

	@Override
	public Application save(Application aplication) {

		return applicationRepository.save(aplication);
	}

	@Override
	public List<Application> searchByName(String keyword) {
		if(null !=keyword) {
		return applicationRepository.findByAppsName(keyword);
		}
		return (List<Application>) applicationRepository.findAll();
	}

}
