package com.springkafkaintegrationproducer.controller;

import java.util.Collections;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("kafka")
public class ProducerController {

	private static String SPRING_INTEGRATION_KAFKA_TOPIC = "spring-integration-kafka.t";

	@Autowired
	private DirectChannel producingChannel;
	
	@GetMapping("producer/{name}")
	public String ProduceMessage(@PathVariable("name") String message) {
		
		Map<String,Object> headers = Collections.singletonMap(KafkaHeaders.TOPIC,SPRING_INTEGRATION_KAFKA_TOPIC);
		
		GenericMessage<String> genericMessage = new GenericMessage<>(message,headers);
	
		producingChannel.send(genericMessage);
		
		return "published successfully";
		
	}
}
