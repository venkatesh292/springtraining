package com.springkafkaconsumer.consumerlistner;

import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;


@Component
@EnableKafka
public class UserListner {

@KafkaListener(topics = "USER_RESOUR", groupId = "group_id")
public void consumeUser(String message) {
	
	System.out.println("Cosumed User: "+ message);
}

@KafkaListener(topics = "USER_RESOUR", groupId = "group_id")
public void consumeUser2(String message) {
	
	System.out.println("Cosumed User 2: "+ message);
}
}
