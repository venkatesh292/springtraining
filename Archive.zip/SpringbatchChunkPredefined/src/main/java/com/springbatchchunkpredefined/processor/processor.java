package com.springbatchchunkpredefined.processor;

import org.springframework.batch.item.ItemProcessor;

import com.springbatchchunkpredefined.model.Employee;

public class processor implements ItemProcessor<Employee,Employee> {

	@Override
	public Employee process(Employee item) throws Exception {
		
		System.out.println("Inserting employee : " + item);
		
		return item;
	}

}
