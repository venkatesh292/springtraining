package com.springbatchchunkpredefined;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbatchChunkPredefinedApplicationTests {

	@Test
	void contextLoads() {
	}

}
