package com.springaopproject.aop.annotation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(0)
public class LoggingAspects {

	private static final Logger LOGGER = LogManager.getLogger(LoggingAspects.class.getName());
/*
	@Before("logPointCut1()")
	public void before(JoinPoint joinpoint) {

		LOGGER.info("Entering Method " + joinpoint.getSignature().getName());
	}

	@After("execution(* com.springaopproject.aop.annotation.EmployeeDaoImpl.getEmployee(..))")
	public void after(JoinPoint joinPoint) {

		LOGGER.info("Completed Method Execution " + joinPoint.getSignature().getName());
	}
*/
	@Around("logPointCut3()")
	public Object log(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {

		String methodName = proceedingJoinPoint.getSignature().getName();
		Object[] arr = proceedingJoinPoint.getArgs();
		
		LOGGER.info("Input to Method: " + methodName + " with agrs: " + arr[0]);
		
		Object result = proceedingJoinPoint.proceed(arr);
		
		LOGGER.info("Method :" + methodName + " returns " + result);
		
		return result;
	}

	/*
	 * Match all methods within a class within same package
	 */
	@Pointcut("execution(* EmployeeDaoImpl.*(..))")
	public void logPointCut1() {
		System.out.println("Entering method");
	}
	
	/**
     * Match all public methods in PassengerDaoImpl
     */
	@Pointcut("execution(public * com.springaopproject.aop.annotation.EmployeeDaoImpl.*(..))")
	public void logPointCut2() {
		System.out.println("Entering method");
	}
	
	/**
     * Match all public methods in PassengerDaoImpl with return type Passenger
     */
	@Pointcut("execution(public Employee com.springaopproject.aop.annotation.EmployeeDaoImpl.*(..))")
	public void logPointCut3() {
		System.out.println("Entering method");
	}
	
	 /**
     * Match all public methods in PassengerDaoImpl with return type Passenger
     * and first parameter as Integer
     */
	@Pointcut("execution(public Employee com.springaopproject.aop.annotation.EmployeeDaoImpl.*(int, ..))")
	public void logPointCut4() {
		System.out.println("Entering method");
	}
	
	/**
     * Match all methods defined in classes inside package com.springaopproject.aop.annotation
     */
	@Pointcut("within(com.springaopproject.aop.annotation.*)")
	public void logPointCut5() {
		System.out.println("Entering method");
	}
	
	/**
     * Match all methods defined in classes inside
     * package com.springaopproject.aop.annotation and classes inside all sub-packages as well
     */
	@Pointcut("within(com.springaopproject.aop.annotation..*)")
	public void logPointCut6() {
		System.out.println("Entering method");
	}
	
	/**
     * Match all methods defined in beans whose name ends with ‘DaoImpl’.
     */
	@Pointcut("bean(*DaoImpl)")
	public void logPointCut7() {
		System.out.println("Entering method");
	}
	
	/**
     * Match all methods with names ending with Manager and DAO
     */
	@Pointcut("bean(*Manager) && bean(*DAO)")
	public void logPointCut8() {
		System.out.println("Entering method");
	}
	
	
	
}
