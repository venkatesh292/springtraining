package com.springaopproject.aop.xmljava;

public class Employee {

	private int emmpId;
	private String empName;
	private String empSalary;
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Employee(int emmpId, String empName, String empSalary) {
		super();
		this.emmpId = emmpId;
		this.empName = empName;
		this.empSalary = empSalary;
	}
	
	
	public int getEmmpId() {
		return emmpId;
	}
	public void setEmmpId(int emmpId) {
		this.emmpId = emmpId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}


	@Override
	public String toString() {
		return "Employee [emmpId=" + emmpId + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}

	
	
	
}
