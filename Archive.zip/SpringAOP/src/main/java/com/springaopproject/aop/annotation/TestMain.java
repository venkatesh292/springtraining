package com.springaopproject.aop.annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.springaopproject.aop.annotation");
		
		context.refresh();
		
		EmployeeDAO empDAO = context.getBean("employeeDaoImpl",EmployeeDaoImpl.class);
		
		Employee employee = empDAO.getEmployee(10);
		
		System.out.println(employee);
		
		context.close();

	}

}
