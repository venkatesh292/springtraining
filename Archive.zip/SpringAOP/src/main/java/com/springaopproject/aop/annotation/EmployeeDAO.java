package com.springaopproject.aop.annotation;

public interface EmployeeDAO {

	Employee getEmployee(int id);
}
