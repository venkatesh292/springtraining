package com.springaopproject.aop.xmljava;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("employaopjavaxml.xml");
		
        EmployeeDaoImpl emp = context.getBean("employeeDaoImpl", EmployeeDaoImpl.class);
		
        Employee employee = new Employee(12,"Suresh","1000");
        
		emp.addEmployee(employee);
		
		Employee emplreturn = emp.getEmployee();
		
		System.out.println(emplreturn);
		
		
	}

}
