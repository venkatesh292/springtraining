package com.springaopproject.aop.annotation;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository("employeeDaoImpl")
public class EmployeeDaoImpl implements EmployeeDAO {

	Map<Integer,Employee> empMap = new HashMap<Integer,Employee>();
	
	public Employee getEmployee(int id) {
		
		if(null != empMap.get(id)) {
			
			return empMap.get(id);	
		}
		
		Employee employee = new  Employee(id,"Ganesh","5000");
		empMap.put(id,employee);
		return employee;		
	}

	
}
