package com.springaopproject.aop.xmljava;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;


@Aspect
public class LoggingAspects {

	private static final Logger LOGGER = LogManager.getLogger(LoggingAspects.class.getName());
	
//	@Before("execution(* com.springaopproject.aop.xmljava.EmployeeDaoImpl.addEmployee(..))")
	@Before("logPointCut1()")
	public void before(JoinPoint joinpoint) {
		
		LOGGER.info("Entering Method "+ joinpoint.getSignature().getName());
	}
	
	@After("execution(* com.springaopproject.aop.xmljava.EmployeeDaoImpl.addEmployee(..))")
	public void after(JoinPoint joinPoint) {
		
		LOGGER.info("Completed Method Execution "+ joinPoint.getSignature().getName());
	}
	
	@Pointcut("execution(* com.springaopproject.aop.xmljava.EmployeeDaoImpl.addEmployee(..))")
	public void logPointCut1() {
	 System.out.println("Entering method");
	}
}
