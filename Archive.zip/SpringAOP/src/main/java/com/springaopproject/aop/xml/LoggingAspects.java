package com.springaopproject.aop.xml;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class LoggingAspects {

	private static final Logger LOGGER = LogManager.getLogger(LoggingAspects.class.getName());
	
	public void before() {
		
		LOGGER.info("------------Entering Method----------------");
	}
	
	public void after() {
		
		LOGGER.info("--------------Completed Method Execution----------------");
	}
}
