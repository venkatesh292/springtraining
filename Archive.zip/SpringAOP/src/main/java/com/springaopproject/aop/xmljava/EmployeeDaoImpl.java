package com.springaopproject.aop.xmljava;

public class EmployeeDaoImpl {

	private Employee employee;
	
	
	public void addEmployee(Employee employee) {
		
		this.employee = employee;
	}
	
	public Employee getEmployee() {
		
		return this.employee;
	}
}
